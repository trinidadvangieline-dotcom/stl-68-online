
import React, { useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import { NumberGrid } from './components/NumberGrid';
import { BetHistory } from './components/BetHistory';
import { TransactionHistory } from './components/TransactionHistory';
import { WithdrawalModal } from './components/WithdrawalModal';
import { WithdrawalHistory } from './components/WithdrawalHistory';
import { GameRulesModal } from './components/GameRulesModal';
import { DepositModal } from './components/DepositModal';
import { ProfileModal } from './components/ProfileModal';
import { SettingsModal } from './components/SettingsModal';
import { ReferralModal } from './components/ReferralModal';
import { Bet, GameResult, Transaction, AppNotification } from './types';
import { playSound, setAudioConfig } from './utils/audio';
import { INITIAL_BALANCE, MIN_BET, MAX_BET, WIN_MULTIPLIER, RAMBOL_WIN_MULTIPLIER, MAX_NUMBER } from './constants';
import { 
  Coins, 
  Trophy, 
  User, 
  PlayCircle, 
  Sparkles, 
  Menu as BurgerIcon, 
  X, 
  History, 
  Settings, 
  LogOut,
  ChevronRight,
  ChevronDown,
  ChevronUp,
  Wallet,
  ArrowDownToLine,
  ArrowUpFromLine,
  AlertCircle,
  CheckCircle2,
  Dices,
  RefreshCcw,
  Receipt,
  BookOpen,
  PlusCircle,
  Share2,
  Activity,
  Clock,
  Star,
  Users,
  Bell,
  Trash2,
  Info,
  Megaphone,
  Copy,
  RotateCcw
} from 'lucide-react';

// Extended type for history display with winner info
interface HistoryEntry extends GameResult {
  topWinner?: {
    name: string;
    amount: number;
    type: 'EXACT' | 'RAMBOL';
  };
}

const MOCK_NAMES = ['User_882', 'JackpotKing', 'LuckyBoi', 'MamaPau', 'STL_Master', 'BettingQueen', 'Winner777', 'ProPunter', 'Baller99'];

const App: React.FC = () => {
  const [balance, setBalance] = useState(INITIAL_BALANCE);
  const [selectedNumbers, setSelectedNumbers] = useState<number[]>([]);
  const [betAmount, setBetAmount] = useState<number>(10);
  const [activeBets, setActiveBets] = useState<Bet[]>([]);
  const [lastPlacedBets, setLastPlacedBets] = useState<Bet[]>([]);
  const [isDrawing, setIsDrawing] = useState(false);
  const [winningNumbers, setWinningNumbers] = useState<number[]>([]);
  const [lastResult, setLastResult] = useState<GameResult | null>(null);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [idCopied, setIdCopied] = useState(false);

  const userId = "883-920-STL";
  const userName = "Alex Gamer";
  
  // App Settings State
  const [appSettings, setAppSettings] = useState({
    volume: 0.5,
    sfxEnabled: true,
    animationsEnabled: true,
    notificationsEnabled: true,
    theme: 'midnight'
  });

  // Apply theme to body
  useEffect(() => {
    document.body.className = `theme-${appSettings.theme}`;
  }, [appSettings.theme]);

  // Seed initial sample winning numbers and winner details
  const [recentResults, setRecentResults] = useState<HistoryEntry[]>([
    {
      winningNumbers: [12, 45],
      timestamp: Date.now() - 1000 * 60 * 12,
      payouts: [],
      topWinner: { name: 'JackpotKing', amount: 5000, type: 'EXACT' }
    },
    {
      winningNumbers: [8, 67],
      timestamp: Date.now() - 1000 * 60 * 25,
      payouts: [],
      topWinner: { name: 'LuckyBoi', amount: 2000, type: 'RAMBOL' }
    },
    {
      winningNumbers: [33, 11],
      timestamp: Date.now() - 1000 * 60 * 40,
      payouts: [],
      topWinner: { name: 'MamaPau', amount: 1000, type: 'RAMBOL' }
    },
    {
      winningNumbers: [3, 22],
      timestamp: Date.now() - 1000 * 60 * 55,
      payouts: [],
      topWinner: { name: 'STL_Master', amount: 7500, type: 'EXACT' }
    }
  ]);
  
  // Notification State
  const [isNotificationOpen, setIsNotificationOpen] = useState(false);
  const [hasNewNotifications, setHasNewNotifications] = useState(true);
  const [notifications, setNotifications] = useState<AppNotification[]>([
    {
      id: 'init-1',
      title: 'Welcome to STL 68',
      message: 'Good luck on your first bet! Exact order pays 500x.',
      type: 'SYSTEM',
      timestamp: Date.now() - 1000 * 60 * 5,
      read: false
    }
  ]);

  // UI State
  const [isBurgerOpen, setIsBurgerOpen] = useState(false);
  const [isTableExpanded, setIsTableExpanded] = useState(false);
  const [isBetHistoryExpanded, setIsBetHistoryExpanded] = useState(false);
  const [isHistoryExpanded, setIsHistoryExpanded] = useState(false);
  const [currentTime, setCurrentTime] = useState(new Date().toLocaleTimeString());
  const [isConfirmModalOpen, setIsConfirmModalOpen] = useState(false);
  const [isTransactionHistoryOpen, setIsTransactionHistoryOpen] = useState(false);
  const [isWithdrawModalOpen, setIsWithdrawModalOpen] = useState(false);
  const [isWithdrawalHistoryOpen, setIsWithdrawalHistoryOpen] = useState(false);
  const [isGameRulesOpen, setIsGameRulesOpen] = useState(false);
  const [isDepositModalOpen, setIsDepositModalOpen] = useState(false);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);
  const [isReferralModalOpen, setIsReferralModalOpen] = useState(false);

  // Update clock for "Live" feel
  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date().toLocaleTimeString()), 1000);
    return () => clearInterval(timer);
  }, []);

  // Sync settings with audio utility
  useEffect(() => {
    setAudioConfig({
      volume: appSettings.volume,
      sfxEnabled: appSettings.sfxEnabled
    });
  }, [appSettings]);

  const addNotification = (notif: Omit<AppNotification, 'id' | 'timestamp' | 'read'>) => {
    const newNotif: AppNotification = {
      ...notif,
      id: Math.random().toString(36).substr(2, 9),
      timestamp: Date.now(),
      read: false
    };
    setNotifications(prev => [newNotif, ...prev].slice(0, 20));
    setHasNewNotifications(true);
  };

  const clearNotifications = () => {
    playSound('click');
    setNotifications([]);
    setHasNewNotifications(false);
  };

  const handleToggleNumber = (num: number) => {
    if (selectedNumbers.includes(num)) {
      setSelectedNumbers(selectedNumbers.filter(n => n !== num));
    } else if (selectedNumbers.length < 2) {
      setSelectedNumbers([...selectedNumbers, num]);
    }
  };

  const handleRandomSelect = () => {
    playSound('click');
    const nums: number[] = [];
    while (nums.length < 2) {
      const r = Math.floor(Math.random() * MAX_NUMBER) + 1;
      if (!nums.includes(r)) nums.push(r);
    }
    setSelectedNumbers(nums);
  };

  const toggleBurger = () => {
    setIsBurgerOpen(!isBurgerOpen);
    if (isNotificationOpen) setIsNotificationOpen(false);
  };

  const toggleNotification = () => {
    setIsNotificationOpen(!isNotificationOpen);
    if (isBurgerOpen) setIsBurgerOpen(false);
    setHasNewNotifications(false);
    playSound('click');
  };

  const toggleTable = () => setIsTableExpanded(!isTableExpanded);
  const toggleBetHistory = () => setIsBetHistoryExpanded(!isBetHistoryExpanded);
  const toggleHistoryBoard = () => setIsHistoryExpanded(!isHistoryExpanded);

  const handleInitiateBet = () => {
    if (lastResult) {
      handleNewRound();
    }
    if (selectedNumbers.length !== 2) return;
    if (betAmount < MIN_BET || betAmount > MAX_BET) return;
    if (balance < betAmount) return;
    playSound('click');
    setIsConfirmModalOpen(true);
  };

  const confirmPlaceBet = () => {
    const newBet: Bet = {
      id: Math.random().toString(36).substr(2, 9),
      numbers: [selectedNumbers[0], selectedNumbers[1]],
      amount: betAmount,
      timestamp: Date.now()
    };

    playSound('chip');
    setActiveBets(prev => [...prev, newBet]);
    setBalance(prev => prev - betAmount);
    setSelectedNumbers([]);
    setIsBetHistoryExpanded(true); 
    setIsConfirmModalOpen(false);
  };

  const handleRebet = () => {
    if (lastPlacedBets.length === 0 || isDrawing) return;
    
    // Clear last result if starting a fresh round with re-bet
    if (lastResult) {
      handleNewRound();
    }

    const totalCost = lastPlacedBets.reduce((acc, bet) => acc + bet.amount, 0);
    if (balance < totalCost) {
      addNotification({
        title: 'Insufficient Balance',
        message: 'You do not have enough funds to repeat your last bets.',
        type: 'SYSTEM'
      });
      return;
    }

    playSound('chip');
    const duplicatedBets = lastPlacedBets.map(bet => ({
      ...bet,
      id: Math.random().toString(36).substr(2, 9),
      timestamp: Date.now()
    }));

    setActiveBets(prev => [...prev, ...duplicatedBets]);
    setBalance(prev => prev - totalCost);
    setIsBetHistoryExpanded(true);
  };

  const handleNewRound = () => {
    setActiveBets([]);
    setLastResult(null);
    setWinningNumbers([]);
  };

  const handleDeposit = (amount: number) => {
    playSound('cash');
    setBalance(prev => prev + amount);
    setTransactions(prev => [...prev, {
      id: `DEP-${Math.random().toString(36).substr(2, 8).toUpperCase()}`,
      betNumbers: [0, 0],
      winningNumbers: [0, 0],
      amount: amount,
      payout: 0,
      isWin: true,
      type: 'DEPOSIT',
      timestamp: Date.now()
    }]);
    addNotification({
      title: 'Deposit Successful',
      message: `$${amount.toLocaleString()} has been added to your balance.`,
      type: 'SYSTEM'
    });
  };

  const handleWithdrawal = (amount: number) => {
    playSound('cash');
    setBalance(prev => prev - amount);
    setTransactions(prev => [...prev, {
      id: `WD-${Math.random().toString(36).substr(2, 8).toUpperCase()}`,
      betNumbers: [0, 0],
      winningNumbers: [0, 0],
      amount: amount,
      payout: -amount,
      isWin: false,
      type: 'WITHDRAWAL',
      timestamp: Date.now()
    }]);
  };

  const handleSettingsSave = (newSettings: typeof appSettings) => {
    setAppSettings(newSettings);
    playSound('click');
  };

  const handleCopyId = () => {
    navigator.clipboard.writeText(userId);
    setIdCopied(true);
    playSound('chip');
    setTimeout(() => setIdCopied(false), 2000);
  };

  const triggerWinConfetti = () => {
    const duration = 3 * 1000;
    const animationEnd = Date.now() + duration;
    const defaults = { startVelocity: 30, spread: 360, ticks: 60, zIndex: 1000 };

    const randomInRange = (min: number, max: number) => Math.random() * (max - min) + min;

    const interval: any = setInterval(function() {
      const timeLeft = animationEnd - Date.now();

      if (timeLeft <= 0) {
        return clearInterval(interval);
      }

      const particleCount = 50 * (timeLeft / duration);
      // since particles fall down, start a bit higher than random
      confetti({ ...defaults, particleCount, origin: { x: randomInRange(0.1, 0.3), y: Math.random() - 0.2 } });
      confetti({ ...defaults, particleCount, origin: { x: randomInRange(0.7, 0.9), y: Math.random() - 0.2 } });
    }, 250);
  };

  const startDraw = async () => {
    if (activeBets.length === 0) return;
    
    setIsDrawing(true);
    setWinningNumbers([]);
    setLastResult(null);

    // Save current active bets as "last placed" before they are processed/cleared
    setLastPlacedBets([...activeBets]);

    // Simulated draw sequence
    for (let i = 0; i < 30; i++) {
       setWinningNumbers([Math.floor(Math.random() * MAX_NUMBER) + 1, Math.floor(Math.random() * MAX_NUMBER) + 1]);
       playSound('tick');
       await new Promise(r => setTimeout(r, 100));
    }

    const finalWinners: [number, number] = [
      Math.floor(Math.random() * MAX_NUMBER) + 1,
      Math.floor(Math.random() * MAX_NUMBER) + 1
    ];
    setWinningNumbers(finalWinners);

    let totalWin = 0;
    const payouts: any[] = [];
    const newTransactions: Transaction[] = [];
    let userWinType: 'EXACT' | 'RAMBOL' | null = null;
    
    activeBets.forEach(bet => {
      const isExactMatch = bet.numbers[0] === finalWinners[0] && bet.numbers[1] === finalWinners[1];
      const isRambolMatch = !isExactMatch && 
                           [...bet.numbers].sort((a, b) => a - b).join(',') === 
                           [...finalWinners].sort((a, b) => a - b).join(',');

      let winAmount = 0;
      let type: Transaction['type'] = 'LOSS';
      let isWin = false;

      if (isExactMatch) {
        winAmount = bet.amount * WIN_MULTIPLIER;
        type = 'EXACT';
        isWin = true;
        userWinType = 'EXACT';
      } else if (isRambolMatch) {
        winAmount = bet.amount * RAMBOL_WIN_MULTIPLIER;
        type = 'RAMBOL';
        isWin = true;
        if (!userWinType) userWinType = 'RAMBOL';
      }

      totalWin += winAmount;
      if (isWin) {
        payouts.push({ betId: bet.id, winAmount });
      }

      newTransactions.push({
        id: `TX-${Math.random().toString(36).substr(2, 8).toUpperCase()}`,
        betNumbers: [...bet.numbers] as [number, number],
        winningNumbers: finalWinners,
        amount: bet.amount,
        payout: winAmount,
        isWin,
        type,
        timestamp: Date.now()
      });
    });

    // Notification for Draw Result
    addNotification({
      title: 'Draw Complete',
      message: `Winning Numbers: ${finalWinners[0].toString().padStart(2, '0')} - ${finalWinners[1].toString().padStart(2, '0')}`,
      type: 'DRAW'
    });

    // Notification for Win
    if (totalWin > 0) {
      addNotification({
        title: userWinType === 'EXACT' ? 'JACKPOT WIN!' : 'WINNER!',
        message: `You won $${totalWin.toLocaleString()} on your ${userWinType} bet!`,
        type: 'WIN'
      });
      // TRIGGER CONFETTI ON WIN
      triggerWinConfetti();
    }

    // Create entry for History with winner sample
    let topWinnerEntry = undefined;
    if (totalWin > 0) {
      topWinnerEntry = {
        name: "You (Alex Gamer)",
        amount: totalWin,
        type: userWinType as 'EXACT' | 'RAMBOL'
      };
    } else {
      if (Math.random() < 0.4) {
        const isMockExact = Math.random() < 0.2;
        const mockAmt = Math.floor(Math.random() * 20) + 1;
        const mockWinnerName = MOCK_NAMES[Math.floor(Math.random() * MOCK_NAMES.length)];
        const prize = mockAmt * (isMockExact ? WIN_MULTIPLIER : RAMBOL_WIN_MULTIPLIER);
        
        topWinnerEntry = {
          name: mockWinnerName,
          amount: prize,
          type: (isMockExact ? 'EXACT' : 'RAMBOL') as 'EXACT' | 'RAMBOL'
        };

        if (prize >= 500) {
           addNotification({
             title: 'Community Big Win',
             message: `${mockWinnerName} just won $${prize.toLocaleString()}!`,
             type: 'WIN'
           });
        }
      }
    }

    const newResult: HistoryEntry = {
      winningNumbers: finalWinners,
      timestamp: Date.now(),
      payouts,
      topWinner: topWinnerEntry
    };

    setTransactions(prev => [...prev, ...newTransactions]);
    setBalance(prev => prev + totalWin);
    setLastResult(newResult);
    setRecentResults(prev => [newResult, ...prev].slice(0, 15));
    setIsDrawing(false);

    if (totalWin > 0) {
      if (totalWin >= 1000) playSound('jackpot');
      else playSound('win');
    } else {
      playSound('loss');
    }
  };

  const menuItems = [
    { icon: <User className="w-5 h-5" />, label: "Profile Details", sub: "Verify identity", onClick: () => { setIsProfileModalOpen(true); setIsBurgerOpen(false); } },
    { icon: <Share2 className="w-5 h-5" />, label: "Invite Friends", sub: "Earn commissions", color: "text-blue-400", onClick: () => { setIsReferralModalOpen(true); setIsBurgerOpen(false); } },
    { icon: <ArrowDownToLine className="w-5 h-5" />, label: "Deposit Funds", sub: "Add money to balance", onClick: () => { setIsDepositModalOpen(true); setIsBurgerOpen(false); } },
    { icon: <Receipt className="w-5 h-5" />, label: "Withdrawal History", sub: "View cash-out records", onClick: () => { setIsWithdrawalHistoryOpen(true); setIsWithdrawalHistoryOpen(false); } },
    { icon: <History className="w-5 h-5" />, label: "Activity History", sub: "Bets & Top-ups", onClick: () => { setIsTransactionHistoryOpen(true); setIsBurgerOpen(false); } },
    { icon: <BookOpen className="w-5 h-5" />, label: "Game Rules", sub: "How to play & payouts", onClick: () => { setIsGameRulesOpen(true); setIsBurgerOpen(false); } },
    { icon: <Settings className="w-5 h-5" />, label: "App Settings", sub: "Audio & Visuals", onClick: () => { setIsSettingsModalOpen(true); setIsBurgerOpen(false); } }
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col p-4 md:p-8 relative">
      <TransactionHistory transactions={transactions} isOpen={isTransactionHistoryOpen} onClose={() => setIsTransactionHistoryOpen(false)} />
      <WithdrawalHistory transactions={transactions} isOpen={isWithdrawalHistoryOpen} onClose={() => setIsWithdrawalHistoryOpen(false)} />
      <WithdrawalModal isOpen={isWithdrawModalOpen} onClose={() => setIsWithdrawModalOpen(false)} balance={balance} onWithdraw={handleWithdrawal} />
      <DepositModal isOpen={isDepositModalOpen} onClose={() => setIsDepositModalOpen(false)} onDeposit={handleDeposit} />
      <ProfileModal isOpen={isProfileModalOpen} onClose={() => setIsProfileModalOpen(false)} balance={balance} />
      <GameRulesModal isOpen={isGameRulesOpen} onClose={() => setIsGameRulesOpen(false)} />
      <SettingsModal isOpen={isSettingsModalOpen} onClose={() => setIsSettingsModalOpen(false)} settings={appSettings} onSave={handleSettingsSave} />
      <ReferralModal isOpen={isReferralModalOpen} onClose={() => setIsReferralModalOpen(false)} />

      {isConfirmModalOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 sm:p-6 bg-black/80 backdrop-blur-md">
          <div className="glass-morphism w-full max-w-md rounded-3xl border border-white/10 shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-300">
            <div className="p-6 bg-gradient-to-br from-yellow-500/10 to-transparent">
              <div className="flex items-center gap-3 mb-6">
                <div className="p-3 bg-yellow-500 rounded-2xl">
                  <AlertCircle className="text-black w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-white tracking-tight">Confirm Your Bet</h3>
                  <p className="text-xs text-slate-400 uppercase tracking-widest font-semibold">Verify Selection</p>
                </div>
              </div>
              <div className="space-y-4 mb-8">
                <div className="bg-slate-900/80 p-4 rounded-2xl border border-slate-800 text-center">
                  <p className="text-[10px] text-slate-500 uppercase font-bold tracking-widest mb-3">Your Couple Choice</p>
                  <div className="flex items-center justify-center gap-6">
                    <div className="w-14 h-14 bg-yellow-500 rounded-full flex items-center justify-center text-2xl font-black text-black shadow-lg">{selectedNumbers[0]}</div>
                    <div className="text-slate-700 font-casino text-3xl">&</div>
                    <div className="w-14 h-14 bg-yellow-500 rounded-full flex items-center justify-center text-2xl font-black text-black shadow-lg">{selectedNumbers[1]}</div>
                  </div>
                </div>
                <div className="flex justify-between items-center bg-slate-900/80 p-4 rounded-2xl border border-slate-800">
                  <span className="text-sm font-semibold text-slate-300">Total Wager</span>
                  <span className="text-2xl font-mono font-black text-yellow-500">${betAmount}</span>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <button onClick={() => setIsConfirmModalOpen(false)} className="py-4 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold rounded-2xl transition-all">Cancel</button>
                <button onClick={confirmPlaceBet} className="py-4 bg-yellow-500 hover:bg-yellow-400 text-black font-black rounded-2xl shadow-lg flex items-center justify-center gap-2">
                  <CheckCircle2 className="w-5 h-5" /> CONFIRM
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Overlays */}
      <div className={`fixed inset-0 bg-black/60 backdrop-blur-sm z-40 transition-opacity duration-300 ${(isBurgerOpen || isNotificationOpen) ? 'opacity-100' : 'opacity-0 pointer-events-none'}`} onClick={() => { setIsBurgerOpen(false); setIsNotificationOpen(false); }} />
      
      {/* Side Notification Drawer */}
      <aside className={`fixed top-0 right-0 h-full w-full max-w-[340px] bg-slate-900 shadow-2xl z-50 transform transition-transform duration-300 ease-out border-l border-slate-800 flex flex-col ${isNotificationOpen ? 'translate-x-0' : 'translate-x-full'}`}>
        <div className="p-6 border-b border-slate-800 flex justify-between items-center bg-slate-950/50">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-yellow-500/10 rounded-lg">
               <Bell className="text-yellow-500 w-5 h-5" />
            </div>
            <h2 className="font-bold text-lg tracking-tight text-white uppercase">Live Notifications</h2>
          </div>
          <button onClick={toggleNotification} className="p-2 hover:bg-slate-800 rounded-full text-slate-400"><X className="w-6 h-6" /></button>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-4 custom-scrollbar">
          {notifications.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-20 text-center opacity-30">
               <Megaphone className="w-12 h-12 mb-4" />
               <p className="text-xs uppercase font-black tracking-widest">No New Alerts</p>
            </div>
          ) : (
            notifications.map((n) => (
              <div key={n.id} className="relative group p-4 rounded-2xl bg-slate-950/40 border border-white/5 hover:border-yellow-500/20 transition-all overflow-hidden">
                <div className="absolute top-0 left-0 w-1 h-full bg-yellow-500/30"></div>
                <div className="flex gap-3">
                  <div className={`mt-0.5 p-1.5 rounded-lg h-fit ${
                    n.type === 'WIN' ? 'bg-green-500/20 text-green-500' :
                    n.type === 'DRAW' ? 'bg-blue-500/20 text-blue-400' :
                    n.type === 'PROMO' ? 'bg-purple-500/20 text-purple-400' :
                    'bg-slate-800 text-slate-400'
                  }`}>
                    {n.type === 'WIN' ? <Trophy className="w-3.5 h-3.5" /> : 
                     n.type === 'DRAW' ? <Clock className="w-3.5 h-3.5" /> : 
                     n.type === 'PROMO' ? <Megaphone className="w-3.5 h-3.5" /> : 
                     <Info className="w-3.5 h-3.5" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-[10px] font-black uppercase text-slate-500 tracking-widest mb-0.5">{n.type}</p>
                    <h4 className="text-sm font-bold text-white truncate">{n.title}</h4>
                    <p className="text-xs text-slate-400 mt-1 leading-relaxed">{n.message}</p>
                    <p className="text-[9px] text-slate-600 font-mono mt-2 uppercase">{new Date(n.timestamp).toLocaleTimeString()}</p>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {notifications.length > 0 && (
          <div className="p-4 border-t border-slate-800 bg-slate-950/50">
            <button 
              onClick={clearNotifications}
              className="w-full py-3 flex items-center justify-center gap-2 text-[10px] font-black text-slate-500 uppercase tracking-widest hover:text-red-400 transition-colors"
            >
              <Trash2 className="w-3.5 h-3.5" />
              Clear All Events
            </button>
          </div>
        )}
      </aside>

      {/* Side Burger Drawer */}
      <aside className={`fixed top-0 right-0 h-full w-full max-w-[320px] bg-slate-900 shadow-2xl z-50 transform transition-transform duration-300 ease-out border-l border-slate-800 flex flex-col ${isBurgerOpen ? 'translate-x-0' : 'translate-x-full'}`}>
        <div className="p-6 border-b border-slate-800 flex justify-between items-center bg-slate-950/50">
          <div className="flex items-center gap-2">
            <Trophy className="text-yellow-500 w-6 h-6" />
            <h2 className="font-casino text-2xl tracking-widest text-yellow-500">STL 68 ONLINE</h2>
          </div>
          <button onClick={toggleBurger} className="p-2 hover:bg-slate-800 rounded-full text-slate-400"><X className="w-6 h-6" /></button>
        </div>
        <div className="flex-1 overflow-y-auto p-4 py-6 space-y-6">
          <div className="glass-morphism p-4 rounded-2xl border-yellow-500/20">
            <div className="mb-4 pb-4 border-b border-white/5 space-y-1">
              <p className="text-sm font-bold text-white tracking-tight">{userName}</p>
              <button 
                onClick={handleCopyId}
                className="flex items-center gap-2 group transition-all active:scale-95"
                title="Click to copy ID"
              >
                <p className="text-[10px] text-slate-500 font-mono tracking-widest group-hover:text-yellow-500/80 transition-colors">ID: {userId}</p>
                <div className="p-1 rounded bg-slate-800 group-hover:bg-slate-700 transition-colors">
                  {idCopied ? (
                    <CheckCircle2 className="w-3 h-3 text-green-500 animate-in zoom-in duration-200" />
                  ) : (
                    <Copy className="w-3 h-3 text-slate-500 group-hover:text-yellow-500" />
                  )}
                </div>
              </button>
            </div>

            <p className="text-sm text-slate-400 uppercase tracking-tighter font-semibold">Current Balance</p>
            <p className="text-xl font-bold font-mono text-yellow-500 mb-4">${balance.toLocaleString()}</p>
            <div className="grid grid-cols-1 gap-2">
              <button onClick={() => {setIsDepositModalOpen(true); setIsBurgerOpen(false);}} className="flex items-center justify-center gap-2 py-2.5 bg-yellow-500 text-black font-bold rounded-xl text-xs w-full"><ArrowDownToLine className="w-3.5 h-3.5" /> DEPOSIT</button>
            </div>
          </div>
          <nav className="space-y-1">
            {menuItems.map((item, idx) => (
              <button key={idx} onClick={item.onClick} className="w-full flex items-center justify-between p-4 rounded-xl hover:bg-slate-800 group">
                <div className="flex items-center gap-4">
                  <div className={`p-2 rounded-lg bg-slate-800 group-hover:bg-slate-700 ${item.color || 'text-slate-300'}`}>{item.icon}</div>
                  <div className="text-left">
                    <p className={`font-semibold ${item.color || 'text-slate-100'}`}>{item.label}</p>
                    <p className="text-[10px] text-slate-500 uppercase">{item.sub}</p>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-600 group-hover:text-yellow-500" />
              </button>
            ))}
          </nav>
        </div>
      </aside>

      <header className="flex flex-col md:flex-row justify-between items-center gap-4 mb-6">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-yellow-500 rounded-full flex items-center justify-center shadow-lg animate-gold-pulse"><Trophy className="text-black w-7 h-7" /></div>
          <div>
            <h1 className="text-3xl font-casino tracking-widest text-yellow-500">STL 68 ONLINE</h1>
            <p className="text-xs text-slate-400 uppercase tracking-tighter">Live Gaming Experience</p>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <div className="glass-morphism px-6 py-2 rounded-full flex items-center gap-3 border-yellow-500/30">
            <Coins className="text-yellow-500 w-5 h-5" />
            <span className="text-xl font-bold font-mono">${balance.toLocaleString()}</span>
            <button onClick={() => setIsDepositModalOpen(true)} className="ml-2 p-1.5 bg-yellow-500 text-black rounded-full hover:scale-110"><PlusCircle className="w-4 h-4" /></button>
          </div>
          
          <button 
            className="glass-morphism p-2 rounded-full text-slate-300 hover:bg-slate-800 transition-all hover:scale-105"
            onClick={() => { setIsWithdrawModalOpen(true); playSound('click'); }}
            title="Cash Out"
          >
            <Wallet className="w-6 h-6" />
          </button>

          {/* Notification Button */}
          <button 
            className="glass-morphism p-2 rounded-full text-slate-300 hover:bg-slate-800 transition-colors relative"
            onClick={toggleNotification}
          >
            <Bell className="w-6 h-6" />
            {hasNewNotifications && (
              <span className="absolute top-1 right-1 w-2.5 h-2.5 bg-red-500 rounded-full border-2 border-slate-900 animate-pulse"></span>
            )}
          </button>

          <button onClick={toggleBurger} className="glass-morphism p-2 rounded-full text-slate-300 hover:bg-slate-800 transition-colors"><BurgerIcon className="w-6 h-6" /></button>
        </div>
      </header>

      <main className="grid grid-cols-1 lg:grid-cols-12 gap-8 flex-1">
        <div className="lg:col-span-4 flex flex-col gap-6">
          
          {/* Winner History Board Section */}
          <div className="glass-morphism rounded-2xl overflow-hidden border border-slate-700/50 shadow-xl">
            <button onClick={toggleHistoryBoard} className="w-full flex items-center justify-between p-4 bg-gradient-to-r from-slate-900/80 to-slate-900/40 hover:bg-slate-800/80 transition-colors">
              <div className="flex items-center gap-2">
                 <Clock className="w-4 h-4 text-blue-400" />
                 <h2 className="text-sm font-bold uppercase tracking-widest text-slate-300">Winner History Board</h2>
              </div>
              {isHistoryExpanded ? <ChevronUp className="w-4 h-4 text-slate-500" /> : <ChevronDown className="w-4 h-4 text-slate-500" />}
            </button>
            <div className={`transition-all duration-300 ease-in-out overflow-hidden ${isHistoryExpanded ? 'max-h-[400px] opacity-100 p-4' : 'max-h-0 opacity-0'}`}>
              <div className="space-y-3 max-h-[300px] overflow-y-auto pr-2 custom-scrollbar">
                {recentResults.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-6 opacity-40">
                    <Users className="w-8 h-8 mb-2" />
                    <p className="text-[10px] uppercase font-bold tracking-widest text-center">No winners recorded yet</p>
                  </div>
                ) : (
                  recentResults.map((res, idx) => (
                    <div key={res.timestamp + idx} className={`flex flex-col p-3 rounded-xl bg-slate-900/60 border border-white/5 hover:border-yellow-500/20 transition-all group relative overflow-hidden ${res.topWinner?.name === "You (Alex Gamer)" ? 'border-green-500/30 bg-green-500/5' : ''}`}>
                       <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-3">
                             <span className="text-[9px] font-mono font-bold text-slate-600">ID #{recentResults.length - idx}</span>
                             <div className="flex gap-1.5">
                                <div className="w-7 h-7 rounded-full bg-white flex items-center justify-center text-slate-900 font-black text-xs shadow-inner group-hover:bg-yellow-500 transition-colors">{res.winningNumbers[0]}</div>
                                <div className="w-7 h-7 rounded-full bg-white flex items-center justify-center text-slate-900 font-black text-xs shadow-inner group-hover:bg-yellow-500 transition-colors">{res.winningNumbers[1]}</div>
                             </div>
                          </div>
                          <div className="text-right">
                             <p className="text-[8px] font-bold text-slate-500 uppercase tracking-tighter">
                               {new Date(res.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                             </p>
                          </div>
                       </div>
                       
                       {res.topWinner ? (
                         <div className="flex items-center justify-between mt-1 pt-2 border-t border-white/5">
                            <div className="flex items-center gap-2">
                               <div className={`p-1 rounded-md ${res.topWinner.type === 'EXACT' ? 'bg-yellow-500/10 text-yellow-500' : 'bg-blue-500/10 text-blue-400'}`}>
                                 <Star className="w-3 h-3 fill-current" />
                               </div>
                               <span className={`text-[10px] font-black uppercase truncate max-w-[90px] ${res.topWinner.name === "You (Alex Gamer)" ? 'text-green-400' : 'text-slate-200'}`}>
                                 {res.topWinner.name}
                               </span>
                            </div>
                            <div className="flex items-center gap-2">
                               <span className={`text-[7px] font-black px-1.5 py-0.5 rounded uppercase ${res.topWinner.type === 'EXACT' ? 'bg-yellow-500/20 text-yellow-500' : 'bg-blue-500/20 text-blue-400'}`}>
                                 {res.topWinner.type}
                               </span>
                               <span className={`text-xs font-black font-mono ${res.topWinner.name === "You (Alex Gamer)" ? 'text-green-400' : 'text-yellow-500'}`}>
                                 +${res.topWinner.amount.toLocaleString()}
                               </span>
                            </div>
                         </div>
                       ) : (
                         <div className="text-center mt-1 pt-1 opacity-20 italic">
                            <span className="text-[8px] uppercase font-black tracking-widest">No payout recorded</span>
                         </div>
                       )}
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>

          <div className="relative aspect-video rounded-2xl overflow-hidden glass-morphism shadow-2xl border-2 border-slate-800 flex flex-col items-center justify-center bg-black">
            <video autoPlay muted loop playsInline className="absolute inset-0 w-full h-full object-cover opacity-60 mix-blend-lighten">
              <source src="https://assets.mixkit.co/videos/preview/mixkit-futuristic-scenery-of-a-room-with-blue-neon-lights-30113-large.mp4" type="video/mp4" />
            </video>
            <div className="absolute inset-0 pointer-events-none bg-gradient-to-t from-black/60 to-transparent"></div>
            <div className="absolute top-4 left-4 flex items-center gap-2 z-10">
              <div className="w-2.5 h-2.5 bg-red-600 rounded-full animate-pulse"></div>
              <span className="text-[10px] font-bold tracking-[0.2em] uppercase text-white">Live Show</span>
            </div>
            <div className="absolute bottom-4 right-4 text-right z-10">
              <p className="text-[10px] font-bold text-white/70 uppercase">Studio 04 - Manila</p>
              <p className="text-xs font-mono text-yellow-500">{currentTime}</p>
            </div>
            <div className="relative z-20 w-full h-full flex items-center justify-center">
              {isDrawing ? (
                <div className="flex flex-col items-center">
                  <div className="flex gap-4 mb-4">
                    <div className="w-16 h-16 rounded-full bg-yellow-400 flex items-center justify-center text-3xl font-bold text-black border-4 border-yellow-200 animate-bounce">{winningNumbers[0] || '?'}</div>
                    <div className="w-16 h-16 rounded-full bg-yellow-400 flex items-center justify-center text-3xl font-bold text-black border-4 border-yellow-200 animate-bounce [animation-delay:0.1s]">{winningNumbers[1] || '?'}</div>
                  </div>
                  <span className="text-yellow-500 font-casino text-2xl animate-pulse tracking-widest">Drawing Results...</span>
                </div>
              ) : lastResult ? (
                <div className="flex flex-col items-center text-center p-4">
                  <div className="bg-black/40 backdrop-blur-md p-6 rounded-3xl border border-white/10 scale-110">
                    <h3 className="text-sm font-bold text-yellow-500 mb-4 uppercase tracking-[0.3em]">Official Draw</h3>
                    <div className="flex gap-4 mb-6">
                      <div className="w-20 h-20 rounded-full bg-white flex items-center justify-center text-4xl font-bold text-slate-900 border-4 border-yellow-500 shadow-xl">{lastResult.winningNumbers[0]}</div>
                      <div className="w-20 h-20 rounded-full bg-white flex items-center justify-center text-4xl font-bold text-slate-900 border-4 border-yellow-500 shadow-xl">{lastResult.winningNumbers[1]}</div>
                    </div>
                    {lastResult.payouts.length > 0 ? (
                      <div className="bg-green-500/20 text-green-400 px-4 py-2 rounded-full font-bold border border-green-500/50 animate-bounce">
                        JACKPOT WINNER!
                      </div>
                    ) : (
                      <div className="text-slate-300 italic text-xs uppercase tracking-widest">Draw Complete</div>
                    )}
                  </div>
                </div>
              ) : (
                <div className="flex flex-col items-center opacity-80">
                  <PlayCircle className="w-16 h-16 text-yellow-500 mb-2 animate-pulse" />
                  <span className="font-casino text-xl tracking-widest uppercase text-white">Standby for Draw</span>
                </div>
              )}
            </div>
          </div>

          <div className="glass-morphism rounded-xl overflow-hidden border border-yellow-500/30 shadow-[0_0_15px_rgba(234,179,8,0.1)] mb-6 animate-in slide-in-from-left-4 duration-500 relative group">
            <div className="absolute inset-0 bg-yellow-500/5 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none"></div>
            <button 
              onClick={toggleTable}
              className="w-full flex items-center justify-between p-4 bg-gradient-to-r from-yellow-900/20 via-slate-900/80 to-slate-900/40 hover:bg-slate-800/80 transition-colors border-b border-yellow-500/10"
            >
              <div className="flex items-center gap-2 text-yellow-500 font-bold">
                <Sparkles className="w-4 h-4 animate-pulse" />
                <span className="uppercase tracking-widest text-xs font-black text-yellow-100 drop-shadow-md">Winning Payouts</span>
              </div>
              {isTableExpanded ? <ChevronUp className="w-4 h-4 text-slate-500" /> : <ChevronDown className="w-4 h-4 text-slate-500" />}
            </button>
            
            <div className={`transition-all duration-300 ease-in-out overflow-hidden ${isTableExpanded ? 'max-h-[500px] opacity-100 p-6' : 'max-h-0 opacity-0'}`}>
              <div className="space-y-4">
                <div className="relative overflow-hidden flex flex-col items-center justify-center gap-1 bg-gradient-to-br from-yellow-900/40 to-slate-900 rounded-xl p-4 border border-yellow-500/40 shadow-lg">
                  <div className="absolute top-0 right-0 p-2 opacity-20">
                     <Trophy className="w-12 h-12 text-yellow-500 rotate-12" />
                  </div>
                  <span className="text-lg font-casino text-white tracking-widest uppercase z-10 text-shadow-sm">Exact Order</span>
                  <div className="flex flex-col items-center z-10">
                    <span className="text-4xl font-black text-yellow-400 font-mono drop-shadow-[0_2px_4px_rgba(0,0,0,0.5)]">
                      ${WIN_MULTIPLIER}x
                    </span>
                    <span className="text-[10px] text-yellow-200/70 font-bold uppercase tracking-widest mt-1">Payout per $1 Bet</span>
                  </div>
                </div>

                <div className="relative overflow-hidden flex flex-col items-center justify-center gap-1 bg-gradient-to-br from-blue-900/40 to-slate-900 rounded-xl p-4 border border-blue-500/30">
                   <div className="absolute top-0 left-0 p-2 opacity-10">
                     <Dices className="w-12 h-12 text-blue-400 -rotate-12" />
                  </div>
                  <span className="text-lg font-casino text-white tracking-widest uppercase z-10">Any Order (Rambol)</span>
                  <div className="flex flex-col items-center z-10">
                    <span className="text-3xl font-black text-blue-400 font-mono drop-shadow-md">
                      ${RAMBOL_WIN_MULTIPLIER}x
                    </span>
                    <span className="text-[10px] text-blue-200/60 font-bold uppercase tracking-widest mt-1">Payout per $1 Bet</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="lg:col-span-8 grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="flex flex-col gap-4">
            <div className="flex justify-between items-end">
              <div>
                <h2 className="text-2xl font-bold">Pick Your Couple</h2>
                <p className="text-sm text-slate-400">Select number 1 then number 2.</p>
              </div>
              <button onClick={handleRandomSelect} disabled={isDrawing} className="flex items-center gap-2 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold rounded-lg"><Dices className="w-3.5 h-3.5 text-yellow-500" /> QUICK PICK</button>
            </div>
            <NumberGrid selectedNumbers={selectedNumbers} onToggleNumber={handleToggleNumber} disabled={selectedNumbers.length === 2 || isDrawing} />
            <BetHistory bets={activeBets} isExpanded={isBetHistoryExpanded} onToggle={toggleBetHistory} winningNumbers={winningNumbers.length === 2 ? winningNumbers : undefined} />
          </div>
          <div className="flex flex-col gap-6">
            <div className="glass-morphism rounded-2xl p-6 flex flex-col gap-6 shadow-xl border-t-2 border-yellow-500/20">
              <h2 className="text-xl font-bold">Wager Details</h2>
              <div className="space-y-2">
                <div className="flex justify-between text-sm"><span className="text-slate-400 uppercase">Bet Amount</span><span className="font-mono text-yellow-500 font-bold">${betAmount}</span></div>
                <input type="range" min={MIN_BET} max={MAX_BET} step={1} value={betAmount} onChange={(e) => setBetAmount(parseInt(e.target.value))} className="w-full h-2 bg-slate-800 rounded-lg appearance-none accent-yellow-500" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                {[1, 10, 20, 50].map(val => (
                  <button key={val} onClick={() => setBetAmount(val)} className={`py-2 rounded-lg text-sm font-bold ${betAmount === val ? 'bg-yellow-500 text-black' : 'bg-slate-800 hover:bg-slate-700'}`}>${val}</button>
                ))}
                <button onClick={() => setBetAmount(MAX_BET)} className={`py-2 rounded-lg text-sm font-bold ${betAmount === MAX_BET ? 'bg-yellow-500 text-black' : 'bg-yellow-500/10 text-yellow-500 border border-yellow-500/30'}`}>MAX</button>
              </div>
              <div className="space-y-3">
                <button onClick={handleInitiateBet} disabled={selectedNumbers.length !== 2 || balance < betAmount || isDrawing} className={`w-full py-4 rounded-xl font-bold text-lg uppercase transition-all ${selectedNumbers.length === 2 && balance >= betAmount && !isDrawing ? 'bg-yellow-500 text-black shadow-lg shadow-yellow-500/20' : 'bg-slate-800 text-slate-600'}`}>Place Bet</button>
                
                {/* USER REQUEST: Re-bet Last Feature */}
                <button 
                  onClick={handleRebet} 
                  disabled={lastPlacedBets.length === 0 || isDrawing} 
                  className={`w-full py-3 rounded-xl font-bold text-sm uppercase transition-all flex items-center justify-center gap-2 border-2 ${lastPlacedBets.length > 0 && !isDrawing ? 'border-yellow-500/30 bg-yellow-500/5 text-yellow-500 hover:bg-yellow-500/10' : 'border-slate-800 text-slate-700 opacity-50'}`}
                >
                  <RotateCcw className="w-4 h-4" />
                  Re-bet Last ({lastPlacedBets.length})
                </button>
              </div>
            </div>
            <div className="space-y-4">
              {lastResult ? (
                 <button onClick={handleNewRound} className="w-full py-4 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-100 font-bold flex items-center justify-center gap-2 border border-slate-700 transition-all active:scale-95"><RefreshCcw className="w-5 h-5" /> NEW ROUND</button>
              ) : (
                <button onClick={startDraw} disabled={activeBets.length === 0 || isDrawing} className={`w-full py-5 rounded-2xl font-casino text-3xl tracking-[0.2em] transition-all relative overflow-hidden ${activeBets.length > 0 && !isDrawing ? 'bg-gradient-to-r from-red-600 to-orange-600 text-white shadow-xl' : 'bg-slate-900 text-slate-700 border-2 border-slate-800'}`}>
                  {isDrawing ? 'DRAWING...' : 'Lucky Draw Now'}
                </button>
              )}
            </div>
          </div>
        </div>
      </main>
      <footer className="mt-8 pt-8 border-t border-slate-800 text-center text-slate-500 text-xs">
        <p>&copy; 2024 STL 68 ONLINE. Payouts calculated based on exact order matching. Gamble Responsibly.</p>
      </footer>
    </div>
  );
};

export default App;
