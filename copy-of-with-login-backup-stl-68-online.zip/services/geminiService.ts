
import { GoogleGenAI } from "@google/genai";
import { HOST_SYSTEM_INSTRUCTION } from "../constants";

// Fix: Initialize with direct access to process.env.API_KEY as per guidelines
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

/**
 * Generates host commentary based on the provided prompt using Gemini 3 Flash.
 */
export const getHostCommentary = async (prompt: string) => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        systemInstruction: HOST_SYSTEM_INSTRUCTION,
        temperature: 0.9,
        topP: 0.95,
      },
    });
    
    // Fix: Access .text property directly (not as a function call) as per SDK specifications
    return response.text || "The balls are rolling, folks! Good luck to everyone!";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "The balls are rolling, folks! Good luck to everyone!";
  }
};
