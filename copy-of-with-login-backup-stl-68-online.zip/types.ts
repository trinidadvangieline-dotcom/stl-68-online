
export interface Bet {
  id: string;
  numbers: [number, number];
  amount: number;
  timestamp: number;
}

export interface GameResult {
  winningNumbers: [number, number];
  timestamp: number;
  payouts: Array<{ betId: string; winAmount: number }>;
}

export interface Transaction {
  id: string;
  betNumbers: [number, number];
  winningNumbers: [number, number];
  amount: number;
  payout: number;
  isWin: boolean;
  type: 'EXACT' | 'RAMBOL' | 'LOSS' | 'WITHDRAWAL' | 'DEPOSIT';
  timestamp: number;
}

export interface HostMessage {
  text: string;
  type: 'neutral' | 'excited' | 'disappointed' | 'welcome';
}

export interface AppNotification {
  id: string;
  title: string;
  message: string;
  type: 'WIN' | 'DRAW' | 'SYSTEM' | 'PROMO';
  timestamp: number;
  read: boolean;
}
