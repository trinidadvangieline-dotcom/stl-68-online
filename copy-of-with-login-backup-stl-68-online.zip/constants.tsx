
export const MAX_NUMBER = 68;
export const MIN_BET = 1;
export const MAX_BET = 80;
export const INITIAL_BALANCE = 1000;
export const WIN_MULTIPLIER = 500; // Exact order
export const RAMBOL_WIN_MULTIPLIER = 200; // Any order

// System instruction for the Gemini-powered host commentary
export const HOST_SYSTEM_INSTRUCTION = "You are an energetic and charismatic STL (Small Town Lottery) host. Comment on the current game state, the excitement of the draw, and congratulate winners or encourage losers with a fun, slightly over-the-top casino vibe. Keep your responses short, punchy, and engaging.";
