
export type SoundType = 'click' | 'chip' | 'tick' | 'win' | 'jackpot' | 'loss' | 'cash' | 'welcome';

const SOUNDS: Record<SoundType, string> = {
  click: 'https://assets.mixkit.co/sfx/preview/mixkit-modern-click-box-check-1120.mp3',
  chip: 'https://assets.mixkit.co/sfx/preview/mixkit-coins-sound-2003.mp3',
  tick: 'https://assets.mixkit.co/sfx/preview/mixkit-game-ball-tap-2073.mp3',
  win: 'https://assets.mixkit.co/sfx/preview/mixkit-winning-chimes-2015.mp3',
  jackpot: 'https://assets.mixkit.co/sfx/preview/mixkit-animated-small-group-applause-523.mp3',
  loss: 'https://assets.mixkit.co/sfx/preview/mixkit-retro-arcade-game-over-3068.mp3',
  cash: 'https://assets.mixkit.co/sfx/preview/mixkit-cash-register-purchase-873.mp3',
  welcome: 'https://assets.mixkit.co/sfx/preview/mixkit-magic-sweep-game-trophy-257.mp3'
};

let audioConfig = {
  volume: 0.5,
  sfxEnabled: true,
};

export const setAudioConfig = (config: Partial<typeof audioConfig>) => {
  audioConfig = { ...audioConfig, ...config };
};

export const playSound = (type: SoundType) => {
  if (!audioConfig.sfxEnabled) return;
  
  try {
    const audio = new Audio(SOUNDS[type]);
    audio.volume = audioConfig.volume;
    const playPromise = audio.play();
    
    if (playPromise !== undefined) {
      playPromise.catch((error) => {
        // Auto-play was prevented or user hasn't interacted with document yet
        // Silently fail in these cases
      });
    }
  } catch (e) {
    console.error("Audio error:", e);
  }
};
