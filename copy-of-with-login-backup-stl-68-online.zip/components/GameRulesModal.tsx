
import React from 'react';
import { X, BookOpen, Target, Zap, Trophy, HelpCircle, Info, ChevronRight, Scale } from 'lucide-react';
import { WIN_MULTIPLIER, RAMBOL_WIN_MULTIPLIER, MAX_NUMBER, MIN_BET, MAX_BET } from '../constants';

interface GameRulesModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const GameRulesModal: React.FC<GameRulesModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const ruleSections = [
    {
      icon: <Target className="w-5 h-5 text-yellow-500" />,
      title: "How to Play",
      description: `Select exactly two numbers from 1 to ${MAX_NUMBER}. The order in which you select them matters for the maximum payout.`
    },
    {
      icon: <Zap className="w-5 h-5 text-blue-400" />,
      title: "Betting Limits",
      description: `Minimum bet is $${MIN_BET} and maximum bet is $${MAX_BET} per combination. You can place multiple combinations per round.`
    },
    {
      icon: <Trophy className="w-5 h-5 text-green-400" />,
      title: "Prizes & Multipliers",
      content: (
        <div className="grid grid-cols-1 gap-3 mt-2">
          <div className="bg-white/5 p-3 rounded-xl border border-white/5">
            <div className="flex justify-between items-center mb-1">
              <span className="text-[10px] font-black uppercase text-yellow-500">Exact Order</span>
              <span className="font-mono font-bold text-white">{WIN_MULTIPLIER}x</span>
            </div>
            <p className="text-[10px] text-slate-400 leading-relaxed">Match both numbers in the exact sequence they are drawn.</p>
          </div>
          <div className="bg-white/5 p-3 rounded-xl border border-white/5">
            <div className="flex justify-between items-center mb-1">
              <span className="text-[10px] font-black uppercase text-blue-400">Rambol Match</span>
              <span className="font-mono font-bold text-white">{RAMBOL_WIN_MULTIPLIER}x</span>
            </div>
            <p className="text-[10px] text-slate-400 leading-relaxed">Match both numbers regardless of the order they appear in the draw.</p>
          </div>
        </div>
      )
    },
    {
      icon: <Scale className="w-5 h-5 text-purple-400" />,
      title: "Fair Play",
      description: "Draws are generated in real-time using a verified random number generator (RNG) in our secure studio environment."
    }
  ];

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 sm:p-6 bg-black/95 backdrop-blur-md">
      <div className="glass-morphism w-full max-w-lg rounded-[2.5rem] border border-white/10 shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-300">
        {/* Header */}
        <div className="p-8 bg-gradient-to-br from-slate-900 to-slate-950 border-b border-white/5 flex justify-between items-center">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-yellow-500/10 rounded-2xl border border-yellow-500/20">
              <BookOpen className="text-yellow-500 w-6 h-6" />
            </div>
            <div>
              <h2 className="text-2xl font-black text-white tracking-tight uppercase">Game Rules</h2>
              <p className="text-[10px] text-slate-500 uppercase tracking-[0.2em] font-bold italic">STL 68 Online Official Guide</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-2 hover:bg-slate-800 rounded-full transition-colors text-slate-400"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Content */}
        <div className="p-8 space-y-6 max-h-[60vh] overflow-y-auto custom-scrollbar">
          {ruleSections.map((section, idx) => (
            <div key={idx} className="flex gap-4">
              <div className="flex-shrink-0 mt-1">{section.icon}</div>
              <div className="space-y-1">
                <h3 className="text-sm font-black text-slate-200 uppercase tracking-wide">{section.title}</h3>
                {section.description && (
                  <p className="text-xs text-slate-400 leading-relaxed font-medium">
                    {section.description}
                  </p>
                )}
                {section.content && section.content}
              </div>
            </div>
          ))}

          <div className="mt-8 p-6 bg-yellow-500/5 rounded-[2rem] border border-yellow-500/10 flex items-start gap-4">
            <HelpCircle className="w-6 h-6 text-yellow-500 flex-shrink-0" />
            <div>
              <p className="text-xs font-bold text-yellow-500/80 uppercase mb-1">Need Support?</p>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                If you encounter any issues with your bets or withdrawals, please contact our 24/7 support team via the Profile section.
              </p>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-6 bg-slate-950/80 border-t border-white/5 text-center">
          <button 
            onClick={onClose}
            className="w-full py-4 bg-yellow-500 hover:bg-yellow-400 text-black font-black rounded-2xl transition-all active:scale-95 shadow-lg shadow-yellow-500/10"
          >
            UNDERSTOOD
          </button>
          <p className="text-[9px] text-slate-600 uppercase tracking-widest mt-4 font-bold">Please Gamble Responsibly</p>
        </div>
      </div>
    </div>
  );
};
