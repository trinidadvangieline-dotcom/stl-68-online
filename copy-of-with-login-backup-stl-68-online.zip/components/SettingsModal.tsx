
import React, { useState } from 'react';
import { X, Volume2, VolumeX, Eye, Bell, Shield, Smartphone, Moon, Sun, Save, RefreshCw, Palette, Check } from 'lucide-react';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: {
    volume: number;
    sfxEnabled: boolean;
    animationsEnabled: boolean;
    notificationsEnabled: boolean;
    theme: string;
  };
  onSave: (newSettings: any) => void;
}

type Tab = 'audio' | 'visual' | 'account';

const THEMES = [
  { id: 'midnight', name: 'Midnight', primary: '#eab308', secondary: '#0f172a' },
  { id: 'aurora', name: 'Aurora', primary: '#2563eb', secondary: '#f8fafc' },
  { id: 'vegas', name: 'Vegas', primary: '#fbbf24', secondary: '#450a0a' },
  { id: 'cyber', name: 'Cyber', primary: '#ec4899', secondary: '#000000' },
];

export const SettingsModal: React.FC<SettingsModalProps> = ({ isOpen, onClose, settings, onSave }) => {
  const [activeTab, setActiveTab] = useState<Tab>('audio');
  const [localSettings, setLocalSettings] = useState(settings);

  if (!isOpen) return null;

  const handleSave = () => {
    onSave(localSettings);
    onClose();
  };

  const handleReset = () => {
    setLocalSettings({
      volume: 0.5,
      sfxEnabled: true,
      animationsEnabled: true,
      notificationsEnabled: true,
      theme: 'midnight'
    });
  };

  const ToggleSwitch = ({ checked, onChange }: { checked: boolean; onChange: () => void }) => (
    <button 
      onClick={onChange}
      className={`w-12 h-6 rounded-full p-1 transition-colors duration-300 ease-in-out ${checked ? 'bg-yellow-500' : 'bg-slate-700'}`}
    >
      <div className={`w-4 h-4 rounded-full bg-white shadow-md transform transition-transform duration-300 ${checked ? 'translate-x-6' : 'translate-x-0'}`} />
    </button>
  );

  return (
    <div className="fixed inset-0 z-[150] flex items-center justify-center p-4 sm:p-6 bg-black/90 backdrop-blur-md">
      <div className="glass-morphism w-full max-w-lg flex flex-col rounded-[2rem] border border-white/10 shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-300">
        
        {/* Header */}
        <div className="p-6 border-b border-white/5 flex justify-between items-center bg-slate-900/50">
          <h2 className="text-xl font-black text-white uppercase tracking-tight">App Settings</h2>
          <button onClick={onClose} className="p-2 hover:bg-slate-800 rounded-full transition-colors text-slate-400">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex flex-1 min-h-[400px]">
          {/* Sidebar Tabs */}
          <div className="w-20 bg-slate-950/50 border-r border-white/5 flex flex-col items-center py-6 gap-6">
            <button 
              onClick={() => setActiveTab('audio')}
              className={`p-3 rounded-xl transition-all ${activeTab === 'audio' ? 'bg-yellow-500 text-black shadow-lg shadow-yellow-500/20' : 'text-slate-500 hover:bg-slate-800'}`}
            >
              <Volume2 className="w-6 h-6" />
            </button>
            <button 
              onClick={() => setActiveTab('visual')}
              className={`p-3 rounded-xl transition-all ${activeTab === 'visual' ? 'bg-yellow-500 text-black shadow-lg shadow-yellow-500/20' : 'text-slate-500 hover:bg-slate-800'}`}
            >
              <Palette className="w-6 h-6" />
            </button>
            <button 
              onClick={() => setActiveTab('account')}
              className={`p-3 rounded-xl transition-all ${activeTab === 'account' ? 'bg-yellow-500 text-black shadow-lg shadow-yellow-500/20' : 'text-slate-500 hover:bg-slate-800'}`}
            >
              <Shield className="w-6 h-6" />
            </button>
          </div>

          {/* Content Area */}
          <div className="flex-1 p-8 bg-gradient-to-br from-slate-900 to-slate-950 overflow-y-auto">
            
            {activeTab === 'audio' && (
              <div className="space-y-8 animate-in slide-in-from-right-4 duration-300">
                <div className="flex items-center gap-3 mb-6">
                  <div className="p-2 bg-slate-800 rounded-lg">
                    <Volume2 className="w-5 h-5 text-yellow-500" />
                  </div>
                  <h3 className="text-lg font-bold text-white">Audio Preferences</h3>
                </div>

                <div className="space-y-6">
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-bold text-slate-300">Master Volume</span>
                      <span className="text-xs font-mono text-yellow-500">{Math.round(localSettings.volume * 100)}%</span>
                    </div>
                    <input 
                      type="range" 
                      min="0" 
                      max="1" 
                      step="0.1"
                      value={localSettings.volume}
                      onChange={(e) => setLocalSettings({...localSettings, volume: parseFloat(e.target.value)})}
                      className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-yellow-500"
                    />
                  </div>

                  <div className="flex items-center justify-between p-4 bg-slate-800/50 rounded-2xl border border-white/5">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-slate-900 rounded-lg text-slate-400">
                        {localSettings.sfxEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
                      </div>
                      <div>
                        <p className="text-sm font-bold text-white">Sound Effects</p>
                        <p className="text-[10px] text-slate-500">Enable game sounds & clicks</p>
                      </div>
                    </div>
                    <ToggleSwitch 
                      checked={localSettings.sfxEnabled} 
                      onChange={() => setLocalSettings({...localSettings, sfxEnabled: !localSettings.sfxEnabled})} 
                    />
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'visual' && (
              <div className="space-y-8 animate-in slide-in-from-right-4 duration-300 pb-4">
                <div className="flex items-center gap-3 mb-6">
                  <div className="p-2 bg-slate-800 rounded-lg">
                    <Palette className="w-5 h-5 text-blue-400" />
                  </div>
                  <h3 className="text-lg font-bold text-white">Theme & Visuals</h3>
                </div>

                <div className="space-y-6">
                  <div className="space-y-3">
                    <p className="text-[10px] uppercase font-black tracking-widest text-slate-500 ml-1">Interface Theme</p>
                    <div className="grid grid-cols-2 gap-3">
                      {THEMES.map((t) => (
                        <button
                          key={t.id}
                          onClick={() => setLocalSettings({...localSettings, theme: t.id})}
                          className={`relative flex flex-col items-center gap-2 p-3 rounded-2xl border transition-all overflow-hidden ${localSettings.theme === t.id ? 'border-yellow-500 bg-yellow-500/10' : 'border-white/5 bg-slate-800/40 hover:bg-slate-800/60'}`}
                        >
                          <div className="flex w-full gap-1 mb-1">
                            <div className="h-2 w-full rounded-full" style={{ backgroundColor: t.primary }}></div>
                            <div className="h-2 w-full rounded-full" style={{ backgroundColor: t.secondary }}></div>
                          </div>
                          <span className={`text-[10px] font-black uppercase ${localSettings.theme === t.id ? 'text-yellow-500' : 'text-slate-400'}`}>{t.name}</span>
                          {localSettings.theme === t.id && (
                            <div className="absolute top-2 right-2">
                              <Check className="w-3 h-3 text-yellow-500" />
                            </div>
                          )}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="flex items-center justify-between p-4 bg-slate-800/50 rounded-2xl border border-white/5">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-slate-900 rounded-lg text-slate-400">
                        <Smartphone className="w-4 h-4" />
                      </div>
                      <div>
                        <p className="text-sm font-bold text-white">Reduced Motion</p>
                        <p className="text-[10px] text-slate-500">Disable complex animations</p>
                      </div>
                    </div>
                    <ToggleSwitch 
                      checked={!localSettings.animationsEnabled} 
                      onChange={() => setLocalSettings({...localSettings, animationsEnabled: !localSettings.animationsEnabled})} 
                    />
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'account' && (
               <div className="space-y-8 animate-in slide-in-from-right-4 duration-300">
               <div className="flex items-center gap-3 mb-6">
                 <div className="p-2 bg-slate-800 rounded-lg">
                   <Bell className="w-5 h-5 text-green-400" />
                 </div>
                 <h3 className="text-lg font-bold text-white">Notifications</h3>
               </div>

               <div className="space-y-4">
                 <div className="flex items-center justify-between p-4 bg-slate-800/50 rounded-2xl border border-white/5">
                   <div className="flex items-center gap-3">
                     <div className="p-2 bg-slate-900 rounded-lg text-slate-400">
                       <Bell className="w-4 h-4" />
                     </div>
                     <div>
                       <p className="text-sm font-bold text-white">Push Notifications</p>
                       <p className="text-[10px] text-slate-500">Win alerts & promos</p>
                     </div>
                   </div>
                   <ToggleSwitch 
                     checked={localSettings.notificationsEnabled} 
                     onChange={() => setLocalSettings({...localSettings, notificationsEnabled: !localSettings.notificationsEnabled})} 
                   />
                 </div>
                 
                 <div className="p-4 rounded-xl bg-yellow-500/5 border border-yellow-500/10 text-[10px] text-slate-400 leading-relaxed">
                   Note: Critical account alerts (withdrawals, logins) cannot be disabled for security reasons.
                 </div>
               </div>
             </div>
            )}

          </div>
        </div>

        {/* Footer */}
        <div className="p-6 border-t border-white/5 bg-slate-900/50 flex justify-between items-center">
          <button 
            onClick={handleReset}
            className="flex items-center gap-2 text-xs font-bold text-slate-500 hover:text-white transition-colors"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            Reset Defaults
          </button>
          <button 
            onClick={handleSave}
            className="px-8 py-3 bg-yellow-500 hover:bg-yellow-400 text-black font-black rounded-xl shadow-lg shadow-yellow-500/20 transition-all active:scale-95 flex items-center gap-2"
          >
            <Save className="w-4 h-4" />
            SAVE CHANGES
          </button>
        </div>

      </div>
    </div>
  );
};
