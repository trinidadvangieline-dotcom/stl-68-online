
import React, { useState, useMemo } from 'react';
import { Transaction } from '../types';
import { X, Calendar, Search, History, ArrowDownToLine, Receipt, ShieldCheck } from 'lucide-react';

interface WithdrawalHistoryProps {
  transactions: Transaction[];
  isOpen: boolean;
  onClose: () => void;
}

export const WithdrawalHistory: React.FC<WithdrawalHistoryProps> = ({ transactions, isOpen, onClose }) => {
  const [filterDate, setFilterDate] = useState<string>('');

  const withdrawalTransactions = useMemo(() => {
    const list = transactions.filter(t => t.type === 'WITHDRAWAL');
    if (!filterDate) return list;
    return list.filter(t => {
      const tDate = new Date(t.timestamp).toISOString().split('T')[0];
      return tDate === filterDate;
    });
  }, [transactions, filterDate]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[90] flex items-center justify-center p-4 sm:p-6 bg-black/95 backdrop-blur-md">
      <div className="glass-morphism w-full max-w-2xl h-[80vh] flex flex-col rounded-[2.5rem] border border-white/10 shadow-2xl overflow-hidden animate-in fade-in slide-in-from-bottom-8 duration-300">
        {/* Header */}
        <div className="p-8 bg-slate-900 border-b border-white/5 flex justify-between items-center">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-blue-500/10 rounded-2xl border border-blue-500/20">
              <History className="text-blue-500 w-6 h-6" />
            </div>
            <div>
              <h2 className="text-2xl font-black text-white tracking-tight uppercase">Withdrawal Log</h2>
              <p className="text-[10px] text-slate-500 uppercase tracking-[0.2em] font-bold">Payout Disbursement History</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-2 hover:bg-slate-800 rounded-full transition-colors text-slate-400"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Filters */}
        <div className="px-8 py-4 bg-slate-900/50 border-b border-white/5 flex flex-col sm:flex-row gap-4 items-center justify-between">
          <div className="relative w-full sm:w-auto">
            <Calendar className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
            <input 
              type="date" 
              value={filterDate}
              onChange={(e) => setFilterDate(e.target.value)}
              className="pl-12 pr-6 py-3 bg-slate-800/80 border border-slate-700 rounded-2xl text-xs font-black text-slate-300 focus:outline-none focus:border-blue-500/50 w-full sm:w-56 transition-all"
            />
          </div>
          <div className="flex items-center gap-6 text-[10px] font-black uppercase tracking-widest text-slate-500">
            <span>Total Logged: <span className="text-white">{withdrawalTransactions.length}</span></span>
            {filterDate && (
              <button 
                onClick={() => setFilterDate('')}
                className="text-blue-500 hover:text-blue-400 transition-colors"
              >
                Clear Filter
              </button>
            )}
          </div>
        </div>

        {/* List */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4 custom-scrollbar">
          {withdrawalTransactions.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center opacity-50 space-y-6">
              <div className="w-20 h-20 rounded-full bg-slate-800/50 flex items-center justify-center border border-white/5">
                <Receipt className="w-10 h-10 text-slate-600" />
              </div>
              <div>
                <p className="text-slate-400 font-black uppercase tracking-[0.3em] text-sm">No withdrawal records</p>
                <p className="text-[10px] text-slate-600 mt-2 uppercase tracking-widest">You haven't cashed out any winnings yet.</p>
              </div>
            </div>
          ) : (
            [...withdrawalTransactions].sort((a,b) => b.timestamp - a.timestamp).map((t) => (
              <div 
                key={t.id} 
                className="group relative bg-slate-900/60 border border-white/5 rounded-3xl p-6 hover:border-blue-500/30 transition-all hover:bg-slate-900/80"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-5">
                    <div className="w-14 h-14 rounded-2xl bg-blue-500/10 flex items-center justify-center text-blue-500 border border-blue-500/20">
                      <ArrowDownToLine className="w-6 h-6" />
                    </div>
                    <div>
                      <div className="flex items-center gap-3">
                        <span className="text-lg font-black font-mono text-white tracking-tighter">
                          ${Math.abs(t.amount).toLocaleString()}
                        </span>
                        <span className="px-2 py-0.5 bg-green-500/20 text-green-500 text-[8px] font-black rounded-md uppercase tracking-widest">Completed</span>
                      </div>
                      <p className="text-[10px] text-slate-500 font-bold uppercase tracking-[0.15em] mt-1">
                        {new Date(t.timestamp).toLocaleString()}
                      </p>
                    </div>
                  </div>
                  
                  <div className="text-right">
                    <p className="text-[9px] text-slate-600 uppercase font-black tracking-widest mb-1">Reference ID</p>
                    <p className="text-xs font-mono font-bold text-slate-400 group-hover:text-blue-400 transition-colors uppercase">
                      {t.id}
                    </p>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer info */}
        <div className="p-6 bg-slate-950 border-t border-white/5 flex items-center justify-center gap-3">
          <ShieldCheck className="w-4 h-4 text-slate-600" />
          <p className="text-[10px] text-slate-600 uppercase tracking-[0.3em] font-black">Encrypted Financial Statement</p>
        </div>
      </div>
    </div>
  );
};
