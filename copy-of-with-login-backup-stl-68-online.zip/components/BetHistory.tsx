
import React from 'react';
import { Bet } from '../types';
import { WIN_MULTIPLIER, RAMBOL_WIN_MULTIPLIER } from '../constants';
import { TrendingUp, ChevronDown, ChevronUp, Trophy, Star } from 'lucide-react';

interface BetHistoryProps {
  bets: Bet[];
  isExpanded: boolean;
  onToggle: () => void;
  winningNumbers?: number[];
}

export const BetHistory: React.FC<BetHistoryProps> = ({ bets, isExpanded, onToggle, winningNumbers }) => {
  const getWinType = (betNumbers: [number, number]) => {
    if (!winningNumbers || winningNumbers.length < 2) return null;
    
    const isExact = betNumbers[0] === winningNumbers[0] && betNumbers[1] === winningNumbers[1];
    if (isExact) return 'EXACT';
    
    const sortedBet = [...betNumbers].sort((a, b) => a - b);
    const sortedWin = [...winningNumbers].sort((a, b) => a - b);
    const isRambol = sortedBet[0] === sortedWin[0] && sortedBet[1] === sortedWin[1];
    
    if (isRambol) return 'RAMBOL';
    return null;
  };

  return (
    <div className="w-full glass-morphism rounded-xl overflow-hidden border border-slate-700/50 shadow-lg mt-4">
      <button 
        onClick={onToggle}
        className="w-full flex items-center justify-between p-4 bg-gradient-to-r from-slate-900/80 to-slate-900/40 hover:bg-slate-800/80 transition-colors"
      >
        <div className="flex items-center gap-2 text-slate-300 font-bold">
          <TrendingUp className="w-4 h-4 text-yellow-500" />
          <h3 className="text-xs font-bold uppercase tracking-widest">Active Bets</h3>
          {bets.length > 0 && (
            <span className="ml-2 px-1.5 py-0.5 bg-yellow-500 text-black text-[10px] rounded-full font-black">
              {bets.length}
            </span>
          )}
        </div>
        <div className="flex items-center gap-3">
          <div className="px-2 py-0.5 bg-yellow-500/10 rounded text-[10px] font-bold text-yellow-500 border border-yellow-500/20">
            500X PAYOUT
          </div>
          {isExpanded ? <ChevronUp className="w-4 h-4 text-slate-500" /> : <ChevronDown className="w-4 h-4 text-slate-500" />}
        </div>
      </button>
      
      <div className={`transition-all duration-300 ease-in-out overflow-hidden ${isExpanded ? 'max-h-[500px] opacity-100 p-4' : 'max-h-0 opacity-0'}`}>
        <div className="space-y-2 max-h-[250px] overflow-y-auto pr-2 custom-scrollbar">
          {bets.length === 0 ? (
            <div className="flex flex-col items-center py-6 text-center bg-slate-800/20 rounded-lg border border-dashed border-slate-700">
              <p className="text-slate-500 text-xs italic">No active bets placed.</p>
              <p className="text-[10px] text-slate-600 uppercase mt-1">Select 2 numbers to start</p>
            </div>
          ) : (
            bets.map((bet) => {
              const winType = getWinType(bet.numbers);
              const isWinner = !!winType;

              return (
                <div 
                  key={bet.id} 
                  className={`
                    relative flex justify-between items-center p-3 rounded-lg border transition-all duration-500
                    ${isWinner 
                      ? 'bg-green-500/10 border-green-500/50 shadow-[0_0_15px_rgba(34,197,94,0.2)] scale-[1.02]' 
                      : 'bg-slate-800/40 border-slate-700/30'}
                    group hover:border-yellow-500/30
                  `}
                >
                  {isWinner && (
                    <div className="absolute -top-2 -left-2 bg-green-500 text-white p-1 rounded-full shadow-lg animate-bounce">
                      <Trophy className="w-3 h-3" />
                    </div>
                  )}

                  <div className="flex flex-col">
                    <span className="text-[10px] text-slate-500 uppercase font-bold tracking-tighter">Selection</span>
                    <div className="flex items-center gap-2">
                      <span className={`font-mono font-bold text-base leading-tight ${isWinner ? 'text-green-400' : 'text-white'}`}>
                        {bet.numbers[0].toString().padStart(2, '0')} • {bet.numbers[1].toString().padStart(2, '0')}
                      </span>
                      {winType === 'EXACT' && (
                        <span className="bg-yellow-500 text-black text-[8px] px-1.5 py-0.5 rounded font-black uppercase tracking-tighter">EXACT</span>
                      )}
                      {winType === 'RAMBOL' && (
                        <span className="bg-blue-500 text-white text-[8px] px-1.5 py-0.5 rounded font-black uppercase tracking-tighter">RAMBOL</span>
                      )}
                    </div>
                  </div>
                  
                  <div className="text-right flex flex-col items-end">
                    <div className="flex items-center gap-1.5">
                      <span className="text-[10px] text-slate-500 uppercase font-bold">Wager:</span>
                      <span className="text-slate-200 font-bold text-sm">${bet.amount}</span>
                    </div>
                    {isWinner ? (
                      <div className="flex items-center gap-1.5 text-green-400 animate-pulse">
                        <Star className="w-3 h-3 fill-current" />
                        <span className="text-[10px] uppercase font-black tracking-tight">WON:</span>
                        <span className="font-black text-sm">
                          ${(bet.amount * (winType === 'EXACT' ? WIN_MULTIPLIER : RAMBOL_WIN_MULTIPLIER)).toLocaleString()}
                        </span>
                      </div>
                    ) : (
                      <div className="flex items-center gap-1.5 text-yellow-500">
                        <span className="text-[10px] uppercase font-black tracking-tight">Max Win:</span>
                        <span className="font-black text-sm">${(bet.amount * WIN_MULTIPLIER).toLocaleString()}</span>
                      </div>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>
        
        {bets.length > 0 && (
          <div className="mt-3 pt-3 border-t border-slate-800 flex justify-between items-center">
            <span className="text-[10px] text-slate-500 uppercase font-bold tracking-widest">Total Active Wager</span>
            <span className="text-sm font-mono font-bold text-yellow-500">
              ${bets.reduce((sum, b) => sum + b.amount, 0).toLocaleString()}
            </span>
          </div>
        )}
      </div>
    </div>
  );
};
