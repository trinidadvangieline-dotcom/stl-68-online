
import React, { useState } from 'react';
import { Trophy, ArrowRight, Lock, Mail, Loader2, User, Gift, ArrowLeft, CheckCircle2, KeyRound, ShieldCheck } from 'lucide-react';
import { playSound } from '../utils/audio';

interface LoginScreenProps {
  onLogin: () => void;
}

type ViewState = 'login' | 'register' | 'forgot_email' | 'forgot_code' | 'forgot_new_pass';

export const LoginScreen: React.FC<LoginScreenProps> = ({ onLogin }) => {
  const [isLoading, setIsLoading] = useState(false);
  const [view, setView] = useState<ViewState>('login');

  // Login Form State
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  // Register Form State
  const [regUsername, setRegUsername] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regConfirmPassword, setRegConfirmPassword] = useState('');
  const [referralCode, setReferralCode] = useState('');

  // Forgot Password State
  const [resetEmail, setResetEmail] = useState('');
  const [resetCode, setResetCode] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');
  const [error, setError] = useState('');

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    // Simulate API call authentication delay
    setTimeout(() => {
      setIsLoading(false);
      playSound('welcome');
      onLogin();
    }, 1500);
  };

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    // Simulate registration API call
    setTimeout(() => {
      setIsLoading(false);
      playSound('welcome');
      onLogin(); // Auto-login after registration
    }, 2000);
  };

  const handleForgotEmailSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');
    // Simulate sending reset code
    setTimeout(() => {
      setIsLoading(false);
      playSound('click');
      setView('forgot_code');
    }, 1500);
  };

  const handleForgotCodeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');
    // Simulate verifying code
    setTimeout(() => {
      if (resetCode.length < 4) {
          setIsLoading(false);
          setError('Invalid verification code');
          playSound('loss');
          return;
      }
      setIsLoading(false);
      playSound('click');
      setView('forgot_new_pass');
    }, 1500);
  };

  const handleNewPassSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newPassword !== confirmNewPassword) {
        setError("Passwords don't match");
        return;
    }
    setIsLoading(true);
    setError('');
    // Simulate password update
    setTimeout(() => {
      setIsLoading(false);
      playSound('welcome');
      setView('login');
      // Reset states
      setResetEmail('');
      setResetCode('');
      setNewPassword('');
      setConfirmNewPassword('');
    }, 1500);
  };

  const toggleView = (newView: ViewState) => {
    playSound('click');
    setView(newView);
    setIsLoading(false);
    setError('');
  };

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center bg-slate-950 overflow-hidden overflow-y-auto">
      {/* Background Effects */}
      <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-5"></div>
      <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-blue-900/20 via-slate-950 to-purple-900/20"></div>
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-yellow-500/10 rounded-full blur-[100px] animate-pulse"></div>

      <div className="relative z-10 w-full max-w-md p-6 my-auto">
        <div className="flex flex-col items-center mb-8 text-center">
          <div className="w-16 h-16 bg-yellow-500 rounded-full flex items-center justify-center shadow-[0_0_40px_rgba(234,179,8,0.3)] mb-4 animate-gold-pulse">
            <Trophy className="text-black w-8 h-8" />
          </div>
          <h1 className="text-4xl font-casino tracking-widest text-white mb-2" style={{ textShadow: '0 0 20px rgba(255,255,255,0.1)' }}>
            STL 68 <span className="text-yellow-500">ONLINE</span>
          </h1>
          <p className="text-slate-400 text-xs font-medium tracking-widest uppercase">The Premium Live Betting Experience</p>
        </div>

        <div className="glass-morphism rounded-3xl p-8 border border-white/10 shadow-2xl backdrop-blur-xl animate-in fade-in zoom-in duration-500 transition-all">
          
          {view === 'login' && (
            <form onSubmit={handleLoginSubmit} className="space-y-5 animate-in slide-in-from-left-4 duration-300">
              <div className="space-y-2">
                <label className="text-[10px] uppercase font-black tracking-widest text-slate-400 ml-1">Username / Email</label>
                <div className="relative group">
                  <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-yellow-500 transition-colors">
                    <Mail className="w-5 h-5" />
                  </div>
                  <input 
                    type="text" 
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full bg-slate-900/50 border border-slate-700 rounded-2xl py-4 pl-12 pr-4 text-white placeholder:text-slate-600 focus:outline-none focus:border-yellow-500 focus:bg-slate-900/80 transition-all font-medium text-sm"
                    placeholder="Enter your ID"
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-[10px] uppercase font-black tracking-widest text-slate-400 ml-1">Password</label>
                <div className="relative group">
                  <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-yellow-500 transition-colors">
                    <Lock className="w-5 h-5" />
                  </div>
                  <input 
                    type="password" 
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full bg-slate-900/50 border border-slate-700 rounded-2xl py-4 pl-12 pr-4 text-white placeholder:text-slate-600 focus:outline-none focus:border-yellow-500 focus:bg-slate-900/80 transition-all font-medium text-sm"
                    placeholder="••••••••"
                    required
                  />
                </div>
              </div>

              <div className="flex items-center justify-between text-xs text-slate-400 font-medium pt-2">
                <label className="flex items-center gap-2 cursor-pointer hover:text-white transition-colors">
                  <input type="checkbox" className="rounded border-slate-700 bg-slate-900 text-yellow-500 focus:ring-yellow-500/50" />
                  Remember me
                </label>
                <button 
                  type="button" 
                  onClick={() => toggleView('forgot_email')}
                  className="hover:text-yellow-500 transition-colors"
                >
                  Forgot Password?
                </button>
              </div>

              <button 
                type="submit" 
                disabled={isLoading}
                className="w-full bg-yellow-500 hover:bg-yellow-400 text-black font-black py-4 rounded-2xl shadow-lg shadow-yellow-500/20 hover:shadow-yellow-500/40 transition-all active:scale-95 flex items-center justify-center gap-2 mt-4 disabled:opacity-70 disabled:cursor-not-allowed"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    AUTHENTICATING...
                  </>
                ) : (
                  <>
                    ENTER LOBBY
                    <ArrowRight className="w-5 h-5" />
                  </>
                )}
              </button>

              <div className="mt-6 text-center">
                <p className="text-xs text-slate-500 font-medium">
                  Don't have an account? 
                  <button 
                    type="button"
                    onClick={() => toggleView('register')}
                    className="text-yellow-500 hover:text-yellow-400 font-bold ml-1 transition-colors"
                  >
                    Register Now
                  </button>
                </p>
              </div>
            </form>
          )}

          {view === 'register' && (
            <form onSubmit={handleRegisterSubmit} className="space-y-4 animate-in slide-in-from-right-4 duration-300">
               <button 
                type="button" 
                onClick={() => toggleView('login')}
                className="flex items-center gap-2 text-slate-400 hover:text-white text-xs font-bold mb-2 transition-colors"
              >
                <ArrowLeft className="w-3 h-3" />
                Back to Login
              </button>

              <div className="space-y-1.5">
                <label className="text-[10px] uppercase font-black tracking-widest text-slate-400 ml-1">Username</label>
                <div className="relative group">
                  <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-yellow-500 transition-colors">
                    <User className="w-4 h-4" />
                  </div>
                  <input 
                    type="text" 
                    value={regUsername}
                    onChange={(e) => setRegUsername(e.target.value)}
                    className="w-full bg-slate-900/50 border border-slate-700 rounded-xl py-3 pl-10 pr-4 text-white placeholder:text-slate-600 focus:outline-none focus:border-yellow-500 focus:bg-slate-900/80 transition-all font-medium text-sm"
                    placeholder="Choose a username"
                    required
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] uppercase font-black tracking-widest text-slate-400 ml-1">Email</label>
                <div className="relative group">
                  <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-yellow-500 transition-colors">
                    <Mail className="w-4 h-4" />
                  </div>
                  <input 
                    type="email" 
                    value={regEmail}
                    onChange={(e) => setRegEmail(e.target.value)}
                    className="w-full bg-slate-900/50 border border-slate-700 rounded-xl py-3 pl-10 pr-4 text-white placeholder:text-slate-600 focus:outline-none focus:border-yellow-500 focus:bg-slate-900/80 transition-all font-medium text-sm"
                    placeholder="Enter email address"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <label className="text-[10px] uppercase font-black tracking-widest text-slate-400 ml-1">Password</label>
                  <div className="relative group">
                    <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-yellow-500 transition-colors">
                      <Lock className="w-4 h-4" />
                    </div>
                    <input 
                      type="password" 
                      value={regPassword}
                      onChange={(e) => setRegPassword(e.target.value)}
                      className="w-full bg-slate-900/50 border border-slate-700 rounded-xl py-3 pl-10 pr-2 text-white placeholder:text-slate-600 focus:outline-none focus:border-yellow-500 focus:bg-slate-900/80 transition-all font-medium text-sm"
                      placeholder="••••••"
                      required
                    />
                  </div>
                </div>
                <div className="space-y-1.5">
                  <label className="text-[10px] uppercase font-black tracking-widest text-slate-400 ml-1">Confirm</label>
                  <div className="relative group">
                    <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-yellow-500 transition-colors">
                      <CheckCircle2 className="w-4 h-4" />
                    </div>
                    <input 
                      type="password" 
                      value={regConfirmPassword}
                      onChange={(e) => setRegConfirmPassword(e.target.value)}
                      className="w-full bg-slate-900/50 border border-slate-700 rounded-xl py-3 pl-10 pr-2 text-white placeholder:text-slate-600 focus:outline-none focus:border-yellow-500 focus:bg-slate-900/80 transition-all font-medium text-sm"
                      placeholder="••••••"
                      required
                    />
                  </div>
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] uppercase font-black tracking-widest text-slate-400 ml-1">Referral Code (Optional)</label>
                <div className="relative group">
                  <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-yellow-500 transition-colors">
                    <Gift className="w-4 h-4" />
                  </div>
                  <input 
                    type="text" 
                    value={referralCode}
                    onChange={(e) => setReferralCode(e.target.value)}
                    className="w-full bg-slate-900/50 border border-slate-700 border-dashed rounded-xl py-3 pl-10 pr-4 text-yellow-500 placeholder:text-slate-600 focus:outline-none focus:border-yellow-500 focus:bg-slate-900/80 transition-all font-mono font-bold text-sm"
                    placeholder="PROMO-CODE"
                  />
                </div>
              </div>

              <button 
                type="submit" 
                disabled={isLoading}
                className="w-full bg-yellow-500 hover:bg-yellow-400 text-black font-black py-4 rounded-2xl shadow-lg shadow-yellow-500/20 hover:shadow-yellow-500/40 transition-all active:scale-95 flex items-center justify-center gap-2 mt-4 disabled:opacity-70 disabled:cursor-not-allowed"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    CREATING ACCOUNT...
                  </>
                ) : (
                  <>
                    COMPLETE REGISTRATION
                    <ArrowRight className="w-5 h-5" />
                  </>
                )}
              </button>

              <div className="mt-6 text-center">
                <p className="text-xs text-slate-500 font-medium">
                  Already have an account? 
                  <button 
                    type="button"
                    onClick={() => toggleView('login')}
                    className="text-yellow-500 hover:text-yellow-400 font-bold ml-1 transition-colors"
                  >
                    Login Here
                  </button>
                </p>
              </div>
            </form>
          )}

          {view === 'forgot_email' && (
            <form onSubmit={handleForgotEmailSubmit} className="space-y-6 animate-in slide-in-from-right-4 duration-300">
              <button 
                type="button" 
                onClick={() => toggleView('login')}
                className="flex items-center gap-2 text-slate-400 hover:text-white text-xs font-bold mb-2 transition-colors"
              >
                <ArrowLeft className="w-3 h-3" />
                Back to Login
              </button>

              <div className="text-center mb-4">
                <div className="w-12 h-12 bg-slate-800 rounded-full flex items-center justify-center mx-auto mb-3 border border-slate-700">
                  <KeyRound className="w-6 h-6 text-yellow-500" />
                </div>
                <h3 className="text-xl font-black text-white uppercase tracking-tight">Reset Password</h3>
                <p className="text-xs text-slate-400 mt-2 leading-relaxed">Enter your registered email address. We'll send you a secure verification code.</p>
              </div>

              <div className="space-y-2">
                <label className="text-[10px] uppercase font-black tracking-widest text-slate-400 ml-1">Email Address</label>
                <div className="relative group">
                  <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-yellow-500 transition-colors">
                    <Mail className="w-5 h-5" />
                  </div>
                  <input 
                    type="email" 
                    value={resetEmail}
                    onChange={(e) => setResetEmail(e.target.value)}
                    className="w-full bg-slate-900/50 border border-slate-700 rounded-2xl py-4 pl-12 pr-4 text-white placeholder:text-slate-600 focus:outline-none focus:border-yellow-500 focus:bg-slate-900/80 transition-all font-medium text-sm"
                    placeholder="Enter your email"
                    required
                  />
                </div>
              </div>

              <button 
                type="submit" 
                disabled={isLoading}
                className="w-full bg-yellow-500 hover:bg-yellow-400 text-black font-black py-4 rounded-2xl shadow-lg shadow-yellow-500/20 hover:shadow-yellow-500/40 transition-all active:scale-95 flex items-center justify-center gap-2 mt-4 disabled:opacity-70 disabled:cursor-not-allowed"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    SENDING...
                  </>
                ) : (
                  <>
                    SEND CODE
                    <ArrowRight className="w-5 h-5" />
                  </>
                )}
              </button>
            </form>
          )}

          {view === 'forgot_code' && (
            <form onSubmit={handleForgotCodeSubmit} className="space-y-6 animate-in slide-in-from-right-4 duration-300">
              <button 
                type="button" 
                onClick={() => toggleView('forgot_email')}
                className="flex items-center gap-2 text-slate-400 hover:text-white text-xs font-bold mb-2 transition-colors"
              >
                <ArrowLeft className="w-3 h-3" />
                Change Email
              </button>

              <div className="text-center mb-4">
                <div className="w-12 h-12 bg-slate-800 rounded-full flex items-center justify-center mx-auto mb-3 border border-slate-700">
                  <ShieldCheck className="w-6 h-6 text-green-500" />
                </div>
                <h3 className="text-xl font-black text-white uppercase tracking-tight">Verify Identity</h3>
                <p className="text-xs text-slate-400 mt-2 leading-relaxed">
                  Enter the 4-digit code sent to <span className="text-white font-bold">{resetEmail}</span>
                </p>
              </div>

              <div className="space-y-2">
                <label className="text-[10px] uppercase font-black tracking-widest text-slate-400 ml-1">Verification Code</label>
                <div className="relative group">
                  <input 
                    type="text" 
                    value={resetCode}
                    onChange={(e) => setResetCode(e.target.value.replace(/\D/g, '').slice(0, 4))}
                    className="w-full bg-slate-900/50 border border-slate-700 rounded-2xl py-4 text-center text-white placeholder:text-slate-700 focus:outline-none focus:border-yellow-500 focus:bg-slate-900/80 transition-all font-mono font-black text-2xl tracking-[0.5em]"
                    placeholder="0000"
                    required
                  />
                </div>
                {error && <p className="text-red-500 text-[10px] font-bold text-center mt-2 animate-pulse">{error}</p>}
              </div>

              <button 
                type="submit" 
                disabled={isLoading}
                className="w-full bg-yellow-500 hover:bg-yellow-400 text-black font-black py-4 rounded-2xl shadow-lg shadow-yellow-500/20 hover:shadow-yellow-500/40 transition-all active:scale-95 flex items-center justify-center gap-2 mt-4 disabled:opacity-70 disabled:cursor-not-allowed"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    VERIFYING...
                  </>
                ) : (
                  <>
                    VERIFY CODE
                    <ArrowRight className="w-5 h-5" />
                  </>
                )}
              </button>

              <div className="text-center">
                 <button type="button" className="text-[10px] text-slate-500 uppercase font-bold hover:text-white transition-colors">Resend Code</button>
              </div>
            </form>
          )}

          {view === 'forgot_new_pass' && (
             <form onSubmit={handleNewPassSubmit} className="space-y-5 animate-in slide-in-from-right-4 duration-300">
              <div className="text-center mb-4">
                <div className="w-12 h-12 bg-slate-800 rounded-full flex items-center justify-center mx-auto mb-3 border border-slate-700">
                  <Lock className="w-6 h-6 text-blue-500" />
                </div>
                <h3 className="text-xl font-black text-white uppercase tracking-tight">New Password</h3>
                <p className="text-xs text-slate-400 mt-2 leading-relaxed">Create a strong password to secure your account.</p>
              </div>

              <div className="space-y-2">
                <label className="text-[10px] uppercase font-black tracking-widest text-slate-400 ml-1">New Password</label>
                <div className="relative group">
                  <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-yellow-500 transition-colors">
                    <Lock className="w-5 h-5" />
                  </div>
                  <input 
                    type="password" 
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    className="w-full bg-slate-900/50 border border-slate-700 rounded-2xl py-4 pl-12 pr-4 text-white placeholder:text-slate-600 focus:outline-none focus:border-yellow-500 focus:bg-slate-900/80 transition-all font-medium text-sm"
                    placeholder="••••••••"
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-[10px] uppercase font-black tracking-widest text-slate-400 ml-1">Confirm Password</label>
                <div className="relative group">
                  <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-yellow-500 transition-colors">
                    <CheckCircle2 className="w-5 h-5" />
                  </div>
                  <input 
                    type="password" 
                    value={confirmNewPassword}
                    onChange={(e) => setConfirmNewPassword(e.target.value)}
                    className="w-full bg-slate-900/50 border border-slate-700 rounded-2xl py-4 pl-12 pr-4 text-white placeholder:text-slate-600 focus:outline-none focus:border-yellow-500 focus:bg-slate-900/80 transition-all font-medium text-sm"
                    placeholder="••••••••"
                    required
                  />
                </div>
              </div>

              {error && <p className="text-red-500 text-[10px] font-bold text-center mt-2 animate-pulse">{error}</p>}

              <button 
                type="submit" 
                disabled={isLoading}
                className="w-full bg-green-500 hover:bg-green-400 text-black font-black py-4 rounded-2xl shadow-lg shadow-green-500/20 hover:shadow-green-500/40 transition-all active:scale-95 flex items-center justify-center gap-2 mt-4 disabled:opacity-70 disabled:cursor-not-allowed"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    UPDATING...
                  </>
                ) : (
                  <>
                    RESET PASSWORD
                    <CheckCircle2 className="w-5 h-5" />
                  </>
                )}
              </button>
            </form>
          )}

        </div>

        <div className="mt-8 text-center opacity-40">
           <p className="text-[9px] uppercase tracking-[0.3em] text-slate-400">Secure 256-bit Encryption</p>
        </div>
      </div>
    </div>
  );
};
