
import React, { useState } from 'react';
import { X, User, Shield, Mail, Phone, CreditCard, Trophy, Settings, Edit, CheckCircle2, AlertCircle, Camera, Award, ArrowLeft, Save, EyeOff, BellRing, Smartphone, Lock } from 'lucide-react';
import { playSound } from '../utils/audio';

interface ProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  balance: number;
}

type ProfileView = 'main' | 'edit' | 'settings';

export const ProfileModal: React.FC<ProfileModalProps> = ({ isOpen, onClose, balance }) => {
  const [view, setView] = useState<ProfileView>('main');
  const [isSaving, setIsSaving] = useState(false);
  
  // Form State
  const [formData, setFormData] = useState({
    name: 'Alex Gamer',
    email: 'alex.gamer@example.com',
    phone: '+63 912 345 6789'
  });

  // Settings State
  const [accountSettings, setAccountSettings] = useState({
    privacyMode: false,
    showLeaderboard: true,
    twoFactor: true,
    smsAlerts: false
  });

  if (!isOpen) return null;

  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    playSound('click');
    setTimeout(() => {
      setIsSaving(false);
      setView('main');
      playSound('welcome');
    }, 1200);
  };

  const toggleSetting = (key: keyof typeof accountSettings) => {
    setAccountSettings(prev => ({ ...prev, [key]: !prev[key] }));
    playSound('chip');
  };

  const handleBack = () => {
    playSound('click');
    setView('main');
  };

  const Toggle = ({ checked, onToggle }: { checked: boolean, onToggle: () => void }) => (
    <button 
      onClick={onToggle}
      className={`w-10 h-5 rounded-full relative transition-colors duration-200 ${checked ? 'bg-yellow-500' : 'bg-slate-700'}`}
    >
      <div className={`absolute top-1 w-3 h-3 rounded-full bg-white transition-all duration-200 ${checked ? 'left-6' : 'left-1'}`} />
    </button>
  );

  return (
    <div className="fixed inset-0 z-[120] flex items-center justify-center p-4 sm:p-6 bg-black/90 backdrop-blur-md">
      <div className="glass-morphism w-full max-w-md max-h-[90vh] flex flex-col rounded-[2.5rem] border border-white/10 shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-300">
        
        {/* Header with decorative background */}
        <div className="relative p-8 pb-12 bg-gradient-to-br from-slate-900 via-blue-950 to-slate-900 border-b border-white/5 overflow-hidden shrink-0">
            <div className="absolute inset-0 opacity-10 bg-[url('https://grainy-gradients.vercel.app/noise.svg')]"></div>
            <div className="absolute -top-10 -right-10 w-40 h-40 bg-blue-500/20 rounded-full blur-3xl"></div>
            
            <div className="relative z-10 flex justify-between items-start">
                <div className="flex flex-col gap-1">
                    <div className="flex items-center gap-2">
                        {view !== 'main' && (
                          <button onClick={handleBack} className="p-1 hover:bg-white/10 rounded-lg text-slate-400 transition-colors mr-1">
                            <ArrowLeft className="w-5 h-5" />
                          </button>
                        )}
                        <h2 className="text-2xl font-black text-white tracking-tight uppercase">
                          {view === 'main' ? 'My Profile' : view === 'edit' ? 'Edit Profile' : 'Account Settings'}
                        </h2>
                    </div>
                    {view === 'main' && (
                      <div className="flex items-center gap-2">
                          <span className="px-2 py-0.5 rounded-md bg-yellow-500 text-black text-[10px] font-black uppercase tracking-widest flex items-center gap-1">
                            <Award className="w-3 h-3" />
                            Gold VIP
                          </span>
                          <span className="text-[10px] text-slate-400 font-mono">ID: 883-920-STL</span>
                      </div>
                    )}
                </div>
                <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-full transition-colors text-slate-300">
                    <X className="w-6 h-6" />
                </button>
            </div>

            {view === 'main' && (
              <div className="absolute -bottom-10 left-8">
                  <div className="relative">
                      <div className="w-24 h-24 rounded-3xl bg-gradient-to-br from-yellow-400 to-yellow-600 p-0.5 shadow-2xl shadow-black/50">
                          <div className="w-full h-full bg-slate-900 rounded-[22px] flex items-center justify-center overflow-hidden relative group">
                               <User className="w-12 h-12 text-yellow-500" />
                               <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center cursor-pointer">
                                  <Camera className="w-6 h-6 text-white" />
                               </div>
                          </div>
                      </div>
                      <div className="absolute -bottom-1 -right-1 bg-green-500 text-black p-1.5 rounded-full border-4 border-slate-950 shadow-sm z-20">
                          <CheckCircle2 className="w-4 h-4 text-white" />
                      </div>
                  </div>
              </div>
            )}
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto custom-scrollbar p-8">
            
            {view === 'main' && (
              <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-300">
                  {/* Name and Status */}
                  <div className="flex justify-between items-end pt-6">
                      <div>
                          <h3 className="text-2xl font-bold text-white tracking-tight">{formData.name}</h3>
                          <p className="text-xs text-slate-500 font-medium font-mono">Member since Sept 2023</p>
                      </div>
                      <div className="flex flex-col items-end">
                           <span className="text-[10px] text-slate-500 uppercase font-black tracking-widest">Trust Score</span>
                           <div className="flex gap-1">
                              {[1,2,3,4,5].map(i => (
                                  <div key={i} className={`w-1.5 h-6 rounded-full transform -skew-x-12 ${i <= 4 ? 'bg-green-500' : 'bg-slate-800'}`}></div>
                              ))}
                           </div>
                      </div>
                  </div>

                  {/* Stats Grid */}
                  <div className="grid grid-cols-2 gap-3">
                      <div className="p-4 bg-slate-800/40 rounded-2xl border border-white/5 hover:bg-slate-800/60 transition-colors group">
                          <div className="flex items-center gap-2 mb-2 text-slate-400 group-hover:text-yellow-500 transition-colors">
                              <CreditCard className="w-4 h-4" />
                              <span className="text-[10px] uppercase font-black tracking-widest">Balance</span>
                          </div>
                          <p className="text-xl font-mono font-bold text-white tracking-tight">${balance.toLocaleString()}</p>
                      </div>
                      <div className="p-4 bg-slate-800/40 rounded-2xl border border-white/5 hover:bg-slate-800/60 transition-colors group">
                          <div className="flex items-center gap-2 mb-2 text-slate-400 group-hover:text-yellow-500 transition-colors">
                               <Trophy className="w-4 h-4" />
                               <span className="text-[10px] uppercase font-black tracking-widest">Win Rate</span>
                          </div>
                           <p className="text-xl font-mono font-bold text-white tracking-tight">42.5%</p>
                      </div>
                  </div>

                  {/* Personal Details */}
                  <div className="space-y-4">
                      <h4 className="text-xs font-black text-slate-500 uppercase tracking-widest border-b border-white/5 pb-2">Account Details</h4>
                      
                      <div className="space-y-3">
                          <div className="flex items-center gap-4 bg-slate-900/30 p-3 rounded-2xl border border-white/5">
                              <div className="w-10 h-10 rounded-xl bg-slate-800 flex items-center justify-center text-slate-400">
                                  <Mail className="w-5 h-5" />
                              </div>
                              <div className="flex-1">
                                  <p className="text-[10px] text-slate-500 uppercase font-bold">Email Address</p>
                                  <div className="flex items-center justify-between">
                                      <p className="text-sm font-bold text-slate-200">{formData.email.replace(/(.{3})(.*)(@.*)/, "$1***$3")}</p>
                                      <span className="px-2 py-0.5 bg-green-500/10 text-green-500 text-[9px] font-black rounded uppercase">Verified</span>
                                  </div>
                              </div>
                          </div>

                          <div className="flex items-center gap-4 bg-slate-900/30 p-3 rounded-2xl border border-white/5">
                              <div className="w-10 h-10 rounded-xl bg-slate-800 flex items-center justify-center text-slate-400">
                                  <Phone className="w-5 h-5" />
                              </div>
                              <div className="flex-1">
                                  <p className="text-[10px] text-slate-500 uppercase font-bold">Phone Number</p>
                                  <div className="flex items-center justify-between">
                                      <p className="text-sm font-bold text-slate-200">{formData.phone.replace(/(\+\d{2} \d{3}) (.*) (\d{3})/, "$1 *** $3")}</p>
                                      <span className="px-2 py-0.5 bg-green-500/10 text-green-500 text-[9px] font-black rounded uppercase">Verified</span>
                                  </div>
                              </div>
                          </div>
                      </div>
                  </div>

                   {/* Security Box */}
                   <div className="p-4 bg-blue-500/10 rounded-2xl border border-blue-500/20 flex items-start gap-3 relative overflow-hidden">
                      <div className="absolute top-0 right-0 w-16 h-16 bg-blue-500/20 blur-2xl rounded-full -mr-8 -mt-8"></div>
                      <AlertCircle className="w-5 h-5 text-blue-400 mt-0.5 relative z-10" />
                      <div className="relative z-10">
                          <p className="text-xs font-bold text-blue-400 mb-1">Security Status: Excellent</p>
                          <p className="text-[10px] text-slate-400 leading-relaxed">
                              Two-Factor Authentication (2FA) is <span className="text-white font-bold">Enabled</span>. Your withdrawals are protected.
                          </p>
                      </div>
                   </div>
              </div>
            )}

            {view === 'edit' && (
              <form onSubmit={handleSaveEdit} className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
                <div className="space-y-4">
                  <div className="space-y-2">
                    <label className="text-[10px] uppercase font-black tracking-widest text-slate-500 ml-1">Display Name</label>
                    <div className="relative group">
                      <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-yellow-500 transition-colors">
                        <User className="w-5 h-5" />
                      </div>
                      <input 
                        type="text" 
                        value={formData.name}
                        onChange={(e) => setFormData({...formData, name: e.target.value})}
                        className="w-full bg-slate-900/50 border border-slate-700 rounded-2xl py-4 pl-12 pr-4 text-white placeholder:text-slate-600 focus:outline-none focus:border-yellow-500 focus:bg-slate-900/80 transition-all font-bold text-sm"
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-[10px] uppercase font-black tracking-widest text-slate-500 ml-1">Email Address</label>
                    <div className="relative group">
                      <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-yellow-500 transition-colors">
                        <Mail className="w-5 h-5" />
                      </div>
                      <input 
                        type="email" 
                        value={formData.email}
                        onChange={(e) => setFormData({...formData, email: e.target.value})}
                        className="w-full bg-slate-900/50 border border-slate-700 rounded-2xl py-4 pl-12 pr-4 text-white placeholder:text-slate-600 focus:outline-none focus:border-yellow-500 focus:bg-slate-900/80 transition-all font-bold text-sm"
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-[10px] uppercase font-black tracking-widest text-slate-500 ml-1">Phone Number</label>
                    <div className="relative group">
                      <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-yellow-500 transition-colors">
                        <Phone className="w-5 h-5" />
                      </div>
                      <input 
                        type="text" 
                        value={formData.phone}
                        onChange={(e) => setFormData({...formData, phone: e.target.value})}
                        className="w-full bg-slate-900/50 border border-slate-700 rounded-2xl py-4 pl-12 pr-4 text-white placeholder:text-slate-600 focus:outline-none focus:border-yellow-500 focus:bg-slate-900/80 transition-all font-bold text-sm"
                        required
                      />
                    </div>
                  </div>

                  <div className="pt-4 space-y-3">
                    <p className="text-[10px] uppercase font-black tracking-widest text-slate-500 ml-1">Password Management</p>
                    <button type="button" className="w-full flex items-center justify-between p-4 bg-slate-800/40 border border-white/5 rounded-2xl text-slate-300 hover:bg-slate-800/60 transition-colors">
                      <div className="flex items-center gap-3">
                        <Lock className="w-4 h-4 text-blue-400" />
                        <span className="text-xs font-bold uppercase">Change Password</span>
                      </div>
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                <div className="flex gap-3 pt-4">
                  <button 
                    type="button"
                    onClick={handleBack}
                    className="flex-1 py-4 bg-slate-800 text-slate-300 font-bold rounded-2xl text-xs uppercase"
                  >
                    Cancel
                  </button>
                  <button 
                    type="submit"
                    disabled={isSaving}
                    className="flex-[2] py-4 bg-yellow-500 text-black font-black rounded-2xl text-xs uppercase flex items-center justify-center gap-2 shadow-lg shadow-yellow-500/20"
                  >
                    {isSaving ? <span className="animate-pulse">Saving...</span> : <><Save className="w-4 h-4" /> Save Changes</>}
                  </button>
                </div>
              </form>
            )}

            {view === 'settings' && (
              <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
                <div className="space-y-3">
                  <h4 className="text-[10px] uppercase font-black tracking-widest text-slate-500 ml-1">Privacy Controls</h4>
                  
                  <div className="space-y-2">
                    <div className="flex items-center justify-between p-4 bg-slate-800/40 border border-white/5 rounded-2xl">
                      <div className="flex items-center gap-3">
                        <EyeOff className="w-5 h-5 text-purple-400" />
                        <div>
                          <p className="text-xs font-bold text-white uppercase">Privacy Mode</p>
                          <p className="text-[9px] text-slate-500">Hide balance on lobby</p>
                        </div>
                      </div>
                      <Toggle checked={accountSettings.privacyMode} onToggle={() => toggleSetting('privacyMode')} />
                    </div>

                    <div className="flex items-center justify-between p-4 bg-slate-800/40 border border-white/5 rounded-2xl">
                      <div className="flex items-center gap-3">
                        <Trophy className="w-5 h-5 text-blue-400" />
                        <div>
                          <p className="text-xs font-bold text-white uppercase">Leaderboard</p>
                          <p className="text-[9px] text-slate-500">Show profile in rankings</p>
                        </div>
                      </div>
                      <Toggle checked={accountSettings.showLeaderboard} onToggle={() => toggleSetting('showLeaderboard')} />
                    </div>
                  </div>
                </div>

                <div className="space-y-3">
                  <h4 className="text-[10px] uppercase font-black tracking-widest text-slate-500 ml-1">Security & Access</h4>
                  
                  <div className="space-y-2">
                    <div className="flex items-center justify-between p-4 bg-slate-800/40 border border-white/5 rounded-2xl">
                      <div className="flex items-center gap-3">
                        <Shield className="w-5 h-5 text-green-400" />
                        <div>
                          <p className="text-xs font-bold text-white uppercase">2FA Auth</p>
                          <p className="text-[9px] text-slate-500">SMS Verification on login</p>
                        </div>
                      </div>
                      <Toggle checked={accountSettings.twoFactor} onToggle={() => toggleSetting('twoFactor')} />
                    </div>

                    <div className="flex items-center justify-between p-4 bg-slate-800/40 border border-white/5 rounded-2xl">
                      <div className="flex items-center gap-3">
                        <BellRing className="w-5 h-5 text-orange-400" />
                        <div>
                          <p className="text-xs font-bold text-white uppercase">SMS Alerts</p>
                          <p className="text-[9px] text-slate-500">Withdrawal notifications</p>
                        </div>
                      </div>
                      <Toggle checked={accountSettings.smsAlerts} onToggle={() => toggleSetting('smsAlerts')} />
                    </div>
                  </div>
                </div>

                <div className="p-4 bg-yellow-500/5 border border-yellow-500/20 rounded-2xl flex items-start gap-3">
                  <Smartphone className="w-5 h-5 text-yellow-500 shrink-0" />
                  <p className="text-[10px] text-slate-400 leading-relaxed font-medium">
                    Account settings are synced across all devices. Changes take effect immediately.
                  </p>
                </div>
              </div>
            )}
        </div>

        {/* Footer */}
        {view === 'main' && (
          <div className="p-4 bg-slate-950 border-t border-white/5 grid grid-cols-2 gap-3 shrink-0">
               <button 
                  onClick={() => { setView('settings'); playSound('click'); }}
                  className="py-3.5 rounded-2xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold transition-colors flex items-center justify-center gap-2 border border-slate-700"
               >
                  <Settings className="w-4 h-4" />
                  SETTINGS
               </button>
               <button 
                  onClick={() => { setView('edit'); playSound('click'); }}
                  className="py-3.5 rounded-2xl bg-yellow-500 hover:bg-yellow-400 text-black text-xs font-black transition-colors flex items-center justify-center gap-2 shadow-lg shadow-yellow-500/20"
               >
                  <Edit className="w-4 h-4" />
                  EDIT PROFILE
               </button>
          </div>
        )}
      </div>
    </div>
  );
};

// Helper component
const ChevronRight = ({ className }: { className?: string }) => (
  <svg className={className} width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m9 18 6-6-6-6"/></svg>
);
