
import React, { useState } from 'react';
import { X, Wallet, ArrowRight, ShieldCheck, Landmark, Smartphone, CreditCard, CheckCircle2, Loader2, PlusCircle } from 'lucide-react';

interface DepositModalProps {
  isOpen: boolean;
  onClose: () => void;
  onDeposit: (amount: number) => void;
}

type Step = 'amount' | 'method' | 'processing' | 'success';
type Method = 'bank' | 'wallet' | 'crypto';

export const DepositModal: React.FC<DepositModalProps> = ({ isOpen, onClose, onDeposit }) => {
  const [step, setStep] = useState<Step>('amount');
  const [amount, setAmount] = useState<string>('');
  const [selectedMethod, setSelectedMethod] = useState<Method>('wallet');
  const [error, setError] = useState<string>('');

  if (!isOpen) return null;

  const handleAmountNext = () => {
    const numAmount = parseFloat(amount);
    if (isNaN(numAmount) || numAmount < 1) {
      setError('Minimum deposit is $1.00');
      return;
    }
    setError('');
    setStep('method');
  };

  const handleProcess = () => {
    setError('');
    setStep('processing');
    
    // Simulate payment gateway delay
    setTimeout(() => {
      onDeposit(parseFloat(amount));
      setStep('success');
    }, 2000);
  };

  const resetAndClose = () => {
    setStep('amount');
    setAmount('');
    setError('');
    onClose();
  };

  const methods = [
    { id: 'wallet', name: 'E-Wallet', icon: <Smartphone className="w-5 h-5" />, providers: ['GCash', 'PayMaya', 'GrabPay'] },
    { id: 'bank', name: 'Bank App', icon: <Landmark className="w-5 h-5" />, providers: ['BPI Online', 'BDO Pay', 'UnionBank'] },
    { id: 'crypto', name: 'Crypto', icon: <CreditCard className="w-5 h-5" />, providers: ['USDT (TRC20)', 'BTC', 'ETH'] },
  ];

  return (
    <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 sm:p-6 bg-black/90 backdrop-blur-md">
      <div className="glass-morphism w-full max-w-md rounded-[2.5rem] border border-white/10 shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-300">
        
        {/* Header */}
        <div className="px-8 pt-8 pb-4">
          <div className="flex justify-between items-center mb-6">
            <div className="flex items-center gap-3">
              <PlusCircle className="text-yellow-500 w-6 h-6" />
              <h2 className="text-2xl font-black text-white tracking-tight uppercase">Add Funds</h2>
            </div>
            <button onClick={resetAndClose} className="p-2 hover:bg-slate-800 rounded-full transition-colors text-slate-400">
              <X className="w-6 h-6" />
            </button>
          </div>
          
          {step !== 'success' && step !== 'processing' && (
            <div className="flex items-center gap-2 mb-8">
              <div className={`h-1.5 flex-1 rounded-full transition-all duration-500 ${step === 'amount' ? 'bg-yellow-500' : 'bg-slate-700'}`}></div>
              <div className={`h-1.5 flex-1 rounded-full transition-all duration-500 ${step === 'method' ? 'bg-yellow-500' : 'bg-slate-700'}`}></div>
            </div>
          )}
        </div>

        <div className="px-8 pb-8">
          {step === 'amount' && (
            <div className="space-y-6 animate-in slide-in-from-right-4 duration-300">
              <div className="space-y-2">
                <label className="text-[10px] text-slate-400 uppercase font-black tracking-widest ml-2">Deposit Amount</label>
                <div className="relative">
                  <span className="absolute left-6 top-1/2 -translate-y-1/2 text-2xl font-black text-slate-500">$</span>
                  <input 
                    type="number"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    placeholder="0.00"
                    className="w-full bg-slate-800/80 border border-slate-700 rounded-3xl py-5 pl-12 pr-6 text-2xl font-mono font-black text-white focus:outline-none focus:border-yellow-500 transition-colors"
                  />
                </div>
                {error && <p className="text-red-400 text-[10px] font-bold uppercase ml-2 tracking-wide">{error}</p>}
              </div>

              <div className="grid grid-cols-3 gap-2">
                {[10, 50, 100, 200, 500, 1000].map((val) => (
                  <button 
                    key={val}
                    onClick={() => setAmount(val.toString())}
                    className="py-3 bg-slate-800/40 hover:bg-slate-800 border border-slate-700 text-slate-300 text-xs font-black rounded-xl transition-all"
                  >
                    +${val}
                  </button>
                ))}
              </div>

              <button 
                onClick={handleAmountNext}
                className="w-full py-5 bg-yellow-500 hover:bg-yellow-400 text-black font-black rounded-3xl shadow-xl shadow-yellow-500/10 transition-all active:scale-95 flex items-center justify-center gap-2"
              >
                CONTINUE
                <ArrowRight className="w-5 h-5" />
              </button>
            </div>
          )}

          {step === 'method' && (
            <div className="space-y-6 animate-in slide-in-from-right-4 duration-300">
              <div className="space-y-3">
                <p className="text-[10px] text-slate-400 uppercase font-black tracking-widest ml-2">Select Method</p>
                <div className="grid grid-cols-3 gap-3">
                  {methods.map((m) => (
                    <button
                      key={m.id}
                      onClick={() => setSelectedMethod(m.id as Method)}
                      className={`flex flex-col items-center gap-2 p-4 rounded-2xl border transition-all ${selectedMethod === m.id ? 'bg-yellow-500/10 border-yellow-500/50 text-yellow-500' : 'bg-slate-800/40 border-slate-700 text-slate-500'}`}
                    >
                      {m.icon}
                      <span className="text-[9px] font-black uppercase tracking-tighter">{m.name}</span>
                    </button>
                  ))}
                </div>
              </div>

              <div className="bg-slate-900/50 p-6 rounded-3xl border border-white/5 space-y-4">
                <div className="flex justify-between text-xs font-bold">
                  <span className="text-slate-500 uppercase">Deposit Amount:</span>
                  <span className="text-white font-mono">${parseFloat(amount).toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-xs font-bold">
                  <span className="text-slate-500 uppercase">Fee:</span>
                  <span className="text-green-500 uppercase">Free</span>
                </div>
                <div className="pt-3 border-t border-white/5 flex justify-between font-black uppercase tracking-tight">
                  <span className="text-slate-300 text-sm">Total:</span>
                  <span className="text-yellow-500 text-lg">${parseFloat(amount).toLocaleString()}</span>
                </div>
              </div>

              <div className="flex gap-3">
                <button 
                  onClick={() => setStep('amount')}
                  className="flex-1 py-4 bg-slate-800 text-slate-300 font-black rounded-2xl"
                >
                  BACK
                </button>
                <button 
                  onClick={handleProcess}
                  className="flex-[2] py-4 bg-yellow-500 hover:bg-yellow-400 text-black font-black rounded-2xl shadow-xl shadow-yellow-500/10"
                >
                  PAY NOW
                </button>
              </div>
            </div>
          )}

          {step === 'processing' && (
            <div className="py-12 flex flex-col items-center text-center space-y-6 animate-in fade-in zoom-in duration-500">
              <div className="relative">
                <Loader2 className="w-24 h-24 text-yellow-500 animate-spin" />
              </div>
              <div>
                <h3 className="text-xl font-black text-white uppercase tracking-tight">Confirming Payment</h3>
                <p className="text-xs text-slate-500 mt-2 font-bold uppercase tracking-widest italic">Awaiting secure handshake...</p>
              </div>
            </div>
          )}

          {step === 'success' && (
            <div className="py-8 flex flex-col items-center text-center space-y-6 animate-in slide-in-from-bottom-8 duration-500">
              <div className="w-24 h-24 bg-green-500 rounded-full flex items-center justify-center shadow-[0_0_30px_rgba(34,197,94,0.4)]">
                <CheckCircle2 className="w-12 h-12 text-white" />
              </div>
              <div>
                <h3 className="text-2xl font-black text-white uppercase tracking-tight">Payment Received</h3>
                <p className="text-xs text-slate-400 mt-2 font-bold uppercase tracking-widest">
                  <span className="text-yellow-500 font-mono text-base">${parseFloat(amount).toLocaleString()}</span> credited to your account.
                </p>
              </div>
              <button 
                onClick={resetAndClose}
                className="w-full py-5 bg-slate-800 hover:bg-slate-700 text-white font-black rounded-3xl"
              >
                GO TO LOBBY
              </button>
            </div>
          )}
        </div>

        <div className="p-4 bg-slate-950 border-t border-white/5 flex items-center justify-center gap-2">
          <ShieldCheck className="w-3 h-3 text-green-500" />
          <p className="text-[9px] text-slate-600 uppercase font-black tracking-widest">PCI DSS Compliant Gateway</p>
        </div>
      </div>
    </div>
  );
};
