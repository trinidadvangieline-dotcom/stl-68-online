
import React, { useState } from 'react';
import { X, Copy, Share2, Users, Gift, CheckCircle2, ChevronRight, Trophy } from 'lucide-react';
import { playSound } from '../utils/audio';

interface ReferralModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ReferralModal: React.FC<ReferralModalProps> = ({ isOpen, onClose }) => {
  const [copied, setCopied] = useState(false);
  // Mock data for the simulation
  const referralCode = "STL-WIN-8823";
  const referralLink = `https://stl68.online/register?ref=${referralCode}`;

  if (!isOpen) return null;

  const handleCopy = () => {
    navigator.clipboard.writeText(referralCode);
    setCopied(true);
    playSound('chip');
    setTimeout(() => setCopied(false), 2000);
  };

  const handleShare = () => {
    playSound('click');
    if (navigator.share) {
      navigator.share({
        title: 'Join me on STL 68 ONLINE',
        text: 'Use my code to get a welcome bonus!',
        url: referralLink,
      }).catch(console.error);
    } else {
      // Fallback for desktop/unsupported
      navigator.clipboard.writeText(referralLink);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="fixed inset-0 z-[130] flex items-center justify-center p-4 sm:p-6 bg-black/95 backdrop-blur-md">
      <div className="glass-morphism w-full max-w-md rounded-[2.5rem] border border-white/10 shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-300">
        
        {/* Header */}
        <div className="relative p-8 bg-gradient-to-br from-purple-900/50 via-slate-900 to-slate-900 border-b border-white/5">
          <div className="absolute top-0 right-0 p-4">
            <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-full transition-colors text-slate-400">
              <X className="w-6 h-6" />
            </button>
          </div>
          <div className="flex flex-col items-center text-center gap-2 mt-2">
            <div className="w-16 h-16 bg-gradient-to-br from-yellow-400 to-yellow-600 rounded-2xl flex items-center justify-center shadow-lg shadow-yellow-500/20 rotate-3">
              <Gift className="w-8 h-8 text-black" />
            </div>
            <h2 className="text-2xl font-black text-white uppercase tracking-tight mt-2">Invite & Earn</h2>
            <p className="text-xs text-slate-400 font-medium">Get <span className="text-yellow-500 font-bold">5% commission</span> from every friend's winning bet!</p>
          </div>
        </div>

        {/* Content */}
        <div className="p-8 space-y-8">
          
          {/* Code Section */}
          <div className="space-y-3">
            <label className="text-[10px] text-slate-500 uppercase font-black tracking-widest ml-1">Your Referral Code</label>
            <div className="relative group">
              <div className="absolute inset-0 bg-yellow-500/20 blur-xl rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity"></div>
              <div className="relative bg-slate-900 border-2 border-dashed border-slate-700 rounded-2xl p-4 flex justify-between items-center hover:border-yellow-500/50 transition-colors">
                <span className="text-xl font-mono font-black text-white tracking-widest">{referralCode}</span>
                <button 
                  onClick={handleCopy}
                  className="p-2 bg-slate-800 hover:bg-yellow-500 hover:text-black rounded-xl transition-all active:scale-95"
                >
                  {copied ? <CheckCircle2 className="w-5 h-5" /> : <Copy className="w-5 h-5" />}
                </button>
              </div>
            </div>
            <button 
              onClick={handleShare}
              className="w-full py-3 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold rounded-xl flex items-center justify-center gap-2 transition-all text-xs uppercase tracking-wide"
            >
              <Share2 className="w-4 h-4" />
              Share Referral Link
            </button>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-slate-800/30 p-4 rounded-2xl border border-white/5">
              <div className="flex items-center gap-2 mb-2 text-blue-400">
                <Users className="w-4 h-4" />
                <span className="text-[9px] uppercase font-black tracking-widest">Invited</span>
              </div>
              <p className="text-2xl font-black text-white">12</p>
            </div>
            <div className="bg-slate-800/30 p-4 rounded-2xl border border-white/5">
              <div className="flex items-center gap-2 mb-2 text-yellow-500">
                <Trophy className="w-4 h-4" />
                <span className="text-[9px] uppercase font-black tracking-widest">Earned</span>
              </div>
              <p className="text-2xl font-black text-white">$450.00</p>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};
