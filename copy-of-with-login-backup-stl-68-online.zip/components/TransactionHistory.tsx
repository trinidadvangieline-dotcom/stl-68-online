
import React, { useState, useMemo } from 'react';
import { Transaction } from '../types';
import { X, Calendar, Search, Filter, ArrowUpRight, ArrowDownRight, TrendingUp, PlusCircle } from 'lucide-react';

interface TransactionHistoryProps {
  transactions: Transaction[];
  isOpen: boolean;
  onClose: () => void;
}

export const TransactionHistory: React.FC<TransactionHistoryProps> = ({ transactions, isOpen, onClose }) => {
  const [filterDate, setFilterDate] = useState<string>('');

  const filteredTransactions = useMemo(() => {
    // Only show bets and deposits in this history (Withdrawals have their own)
    const list = transactions.filter(t => t.type !== 'WITHDRAWAL');
    if (!filterDate) return list;
    return list.filter(t => {
      const tDate = new Date(t.timestamp).toISOString().split('T')[0];
      return tDate === filterDate;
    });
  }, [transactions, filterDate]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center p-4 sm:p-6 bg-black/90 backdrop-blur-md">
      <div className="glass-morphism w-full max-w-2xl h-[80vh] flex flex-col rounded-3xl border border-white/10 shadow-2xl overflow-hidden animate-in fade-in slide-in-from-bottom-4 duration-300">
        {/* Header */}
        <div className="p-6 bg-gradient-to-r from-slate-900 to-slate-900/50 border-b border-white/5 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-yellow-500/10 rounded-xl border border-yellow-500/20">
              <TrendingUp className="text-yellow-500 w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-white tracking-tight">Activity History</h2>
              <p className="text-[10px] text-slate-500 uppercase tracking-widest font-bold">Bets & Deposits</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-2 hover:bg-slate-800 rounded-full transition-colors text-slate-400"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Filters */}
        <div className="px-6 py-4 bg-slate-900/30 border-b border-white/5 flex flex-col sm:flex-row gap-4 items-center justify-between">
          <div className="relative w-full sm:w-auto">
            <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
            <input 
              type="date" 
              value={filterDate}
              onChange={(e) => setFilterDate(e.target.value)}
              className="pl-10 pr-4 py-2 bg-slate-800 border border-slate-700 rounded-xl text-xs font-bold text-slate-300 focus:outline-none focus:border-yellow-500/50 w-full sm:w-48 transition-colors"
            />
          </div>
          <div className="flex items-center gap-4 text-[10px] font-bold uppercase tracking-widest text-slate-500">
            <span>Total Records: <span className="text-white">{filteredTransactions.length}</span></span>
            {filterDate && (
              <button 
                onClick={() => setFilterDate('')}
                className="text-yellow-500 hover:text-yellow-400 transition-colors"
              >
                Clear Filter
              </button>
            )}
          </div>
        </div>

        {/* List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3 custom-scrollbar">
          {filteredTransactions.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center opacity-50 space-y-4">
              <div className="w-16 h-16 rounded-full bg-slate-800 flex items-center justify-center">
                <Filter className="w-8 h-8 text-slate-600" />
              </div>
              <div>
                <p className="text-slate-400 font-bold uppercase tracking-widest text-xs">No records found</p>
                <p className="text-[10px] text-slate-600 mt-1 uppercase tracking-widest">Start playing or top up your account!</p>
              </div>
            </div>
          ) : (
            [...filteredTransactions].sort((a,b) => b.timestamp - a.timestamp).map((t) => {
              const isDeposit = t.type === 'DEPOSIT';
              
              return (
                <div 
                  key={t.id} 
                  className={`group relative bg-slate-900/40 border border-white/5 rounded-2xl p-4 transition-all hover:bg-slate-900/60 ${isDeposit ? 'border-blue-500/10' : ''}`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center 
                        ${isDeposit ? 'bg-blue-500/20 text-blue-500' : (t.isWin ? 'bg-green-500/20 text-green-500' : 'bg-red-500/20 text-red-500')}`}>
                        {isDeposit ? <PlusCircle className="w-5 h-5" /> : (t.isWin ? <ArrowUpRight className="w-5 h-5" /> : <ArrowDownRight className="w-5 h-5" />)}
                      </div>
                      <div>
                        {isDeposit ? (
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-white uppercase tracking-tight text-sm">Account Top Up</span>
                          </div>
                        ) : (
                          <div className="flex items-center gap-2">
                            <span className="font-mono text-sm font-bold text-white">
                              {t.betNumbers[0].toString().padStart(2, '0')} • {t.betNumbers[1].toString().padStart(2, '0')}
                            </span>
                            <span className="text-[10px] text-slate-600 font-bold uppercase tracking-tighter">vs</span>
                            <span className="font-mono text-sm font-bold text-yellow-500/80">
                              {t.winningNumbers[0].toString().padStart(2, '0')} • {t.winningNumbers[1].toString().padStart(2, '0')}
                            </span>
                          </div>
                        )}
                        <p className="text-[9px] text-slate-500 font-bold uppercase tracking-widest mt-0.5">
                          {new Date(t.timestamp).toLocaleString()}
                        </p>
                      </div>
                    </div>
                    
                    <div className="text-right">
                      <div className="flex items-center gap-1.5 justify-end">
                        <span className="text-[10px] text-slate-500 uppercase font-bold">{isDeposit ? 'Added' : 'Payout'}:</span>
                        <span className={`text-sm font-black font-mono 
                          ${isDeposit ? 'text-blue-400' : (t.isWin ? 'text-green-500' : 'text-slate-400')}`}>
                          ${Math.abs(isDeposit ? t.amount : t.payout).toLocaleString()}
                        </span>
                      </div>
                      {!isDeposit && (
                        <div className="flex items-center gap-1.5 justify-end">
                          <span className="text-[9px] text-slate-600 uppercase font-bold">Wager:</span>
                          <span className="text-[10px] text-slate-500 font-bold">${t.amount}</span>
                        </div>
                      )}
                    </div>
                  </div>
                  
                  {(t.isWin || isDeposit) && (
                     <div className={`absolute top-0 right-0 -mt-1 -mr-1 px-2 py-0.5 text-[8px] font-black text-white rounded-full uppercase tracking-widest shadow-lg 
                       ${isDeposit ? 'bg-blue-600' : 'bg-green-500'}`}>
                       {t.type}
                     </div>
                  )}
                </div>
              );
            })
          )}
        </div>

        {/* Footer Info */}
        <div className="p-4 bg-slate-950 border-t border-white/5 text-center">
          <p className="text-[9px] text-slate-600 uppercase tracking-widest font-bold italic">Session Data Only</p>
        </div>
      </div>
    </div>
  );
};
