
import React, { useState } from 'react';
import { X, Wallet, ArrowRight, ShieldCheck, Landmark, Smartphone, CreditCard, CheckCircle2, Loader2 } from 'lucide-react';

interface WithdrawalModalProps {
  isOpen: boolean;
  onClose: () => void;
  balance: number;
  onWithdraw: (amount: number) => void;
}

type Step = 'amount' | 'method' | 'processing' | 'success';
type Method = 'bank' | 'wallet' | 'crypto';

export const WithdrawalModal: React.FC<WithdrawalModalProps> = ({ isOpen, onClose, balance, onWithdraw }) => {
  const [step, setStep] = useState<Step>('amount');
  const [amount, setAmount] = useState<string>('');
  const [selectedMethod, setSelectedMethod] = useState<Method>('wallet');
  const [accountInfo, setAccountInfo] = useState({ provider: '', account: '' });
  const [error, setError] = useState<string>('');

  if (!isOpen) return null;

  const handleAmountNext = () => {
    const numAmount = parseFloat(amount);
    if (isNaN(numAmount) || numAmount <= 0) {
      setError('Please enter a valid amount');
      return;
    }
    if (numAmount > balance) {
      setError('Insufficient balance');
      return;
    }
    setError('');
    setStep('method');
  };

  const handleProcess = () => {
    if (!accountInfo.provider || !accountInfo.account) {
      setError('Please fill in all details');
      return;
    }
    setError('');
    setStep('processing');
    
    // Simulate processing delay
    setTimeout(() => {
      onWithdraw(parseFloat(amount));
      setStep('success');
    }, 2500);
  };

  const resetAndClose = () => {
    setStep('amount');
    setAmount('');
    setAccountInfo({ provider: '', account: '' });
    setError('');
    onClose();
  };

  const methods = [
    { id: 'wallet', name: 'Digital Wallet', icon: <Smartphone className="w-5 h-5" />, providers: ['GCash', 'PayMaya', 'ShopeePay'] },
    { id: 'bank', name: 'Bank Transfer', icon: <Landmark className="w-5 h-5" />, providers: ['BPI', 'BDO', 'UnionBank', 'Metrobank'] },
    { id: 'crypto', name: 'Crypto Wallet', icon: <CreditCard className="w-5 h-5" />, providers: ['Binance (USDT)', 'Coinbase', 'MetaMask'] },
  ];

  return (
    <div className="fixed inset-0 z-[80] flex items-center justify-center p-4 sm:p-6 bg-black/95 backdrop-blur-sm">
      <div className="glass-morphism w-full max-w-md rounded-[2.5rem] border border-white/10 shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-300">
        
        {/* Progress Header */}
        <div className="px-8 pt-8 pb-4">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-black text-white tracking-tight uppercase">Cash Out</h2>
            <button onClick={resetAndClose} className="p-2 hover:bg-slate-800 rounded-full transition-colors text-slate-400">
              <X className="w-6 h-6" />
            </button>
          </div>
          
          {step !== 'success' && step !== 'processing' && (
            <div className="flex items-center gap-2 mb-8">
              <div className={`h-1.5 flex-1 rounded-full transition-all duration-500 ${step === 'amount' ? 'bg-yellow-500' : 'bg-slate-700'}`}></div>
              <div className={`h-1.5 flex-1 rounded-full transition-all duration-500 ${step === 'method' ? 'bg-yellow-500' : 'bg-slate-700'}`}></div>
            </div>
          )}
        </div>

        <div className="px-8 pb-8">
          {step === 'amount' && (
            <div className="space-y-6 animate-in slide-in-from-right-4 duration-300">
              <div className="bg-slate-900/50 p-6 rounded-3xl border border-white/5 text-center">
                <p className="text-[10px] text-slate-500 uppercase font-black tracking-widest mb-1">Available to Withdraw</p>
                <p className="text-3xl font-mono font-black text-yellow-500">${balance.toLocaleString()}</p>
              </div>

              <div className="space-y-2">
                <label className="text-[10px] text-slate-400 uppercase font-black tracking-widest ml-2">Amount to Withdraw</label>
                <div className="relative">
                  <span className="absolute left-6 top-1/2 -translate-y-1/2 text-2xl font-black text-slate-500">$</span>
                  <input 
                    type="number"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    placeholder="0.00"
                    className="w-full bg-slate-800/80 border border-slate-700 rounded-3xl py-5 pl-12 pr-6 text-2xl font-mono font-black text-white focus:outline-none focus:border-yellow-500 transition-colors"
                  />
                </div>
                {error && <p className="text-red-400 text-[10px] font-bold uppercase ml-2 tracking-wide">{error}</p>}
              </div>

              <div className="grid grid-cols-3 gap-2">
                {[0.25, 0.5, 1].map((p) => (
                  <button 
                    key={p}
                    onClick={() => setAmount((balance * p).toFixed(2))}
                    className="py-2 bg-slate-800/40 hover:bg-slate-800 border border-slate-700 text-slate-300 text-[10px] font-black rounded-xl transition-all"
                  >
                    {p === 1 ? 'ALL' : `${p * 100}%`}
                  </button>
                ))}
              </div>

              <button 
                onClick={handleAmountNext}
                className="w-full py-5 bg-yellow-500 hover:bg-yellow-400 text-black font-black rounded-3xl shadow-xl shadow-yellow-500/10 transition-all active:scale-95 flex items-center justify-center gap-2"
              >
                NEXT STEP
                <ArrowRight className="w-5 h-5" />
              </button>
            </div>
          )}

          {step === 'method' && (
            <div className="space-y-6 animate-in slide-in-from-right-4 duration-300">
              <div className="space-y-3">
                <p className="text-[10px] text-slate-400 uppercase font-black tracking-widest ml-2">Choose Method</p>
                <div className="grid grid-cols-3 gap-3">
                  {methods.map((m) => (
                    <button
                      key={m.id}
                      onClick={() => {
                        setSelectedMethod(m.id as Method);
                        setAccountInfo({ ...accountInfo, provider: '' });
                      }}
                      className={`flex flex-col items-center gap-2 p-4 rounded-2xl border transition-all ${selectedMethod === m.id ? 'bg-yellow-500/10 border-yellow-500/50 text-yellow-500' : 'bg-slate-800/40 border-slate-700 text-slate-500'}`}
                    >
                      {m.icon}
                      <span className="text-[9px] font-black uppercase tracking-tighter">{m.name}</span>
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="text-[10px] text-slate-400 uppercase font-black tracking-widest ml-2">Provider</label>
                  <select 
                    value={accountInfo.provider}
                    onChange={(e) => setAccountInfo({ ...accountInfo, provider: e.target.value })}
                    className="w-full bg-slate-800/80 border border-slate-700 rounded-2xl p-4 text-sm font-bold text-white focus:outline-none appearance-none"
                  >
                    <option value="" disabled>Select Provider</option>
                    {methods.find(m => m.id === selectedMethod)?.providers.map(p => (
                      <option key={p} value={p}>{p}</option>
                    ))}
                  </select>
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] text-slate-400 uppercase font-black tracking-widest ml-2">Account Number / Phone</label>
                  <input 
                    type="text"
                    value={accountInfo.account}
                    onChange={(e) => setAccountInfo({ ...accountInfo, account: e.target.value })}
                    placeholder="Enter details..."
                    className="w-full bg-slate-800/80 border border-slate-700 rounded-2xl p-4 text-sm font-bold text-white focus:outline-none focus:border-yellow-500"
                  />
                </div>
              </div>

              {error && <p className="text-red-400 text-[10px] font-bold uppercase ml-2 tracking-wide">{error}</p>}

              <div className="flex gap-3">
                <button 
                  onClick={() => setStep('amount')}
                  className="flex-1 py-4 bg-slate-800 text-slate-300 font-black rounded-2xl"
                >
                  BACK
                </button>
                <button 
                  onClick={handleProcess}
                  className="flex-[2] py-4 bg-yellow-500 hover:bg-yellow-400 text-black font-black rounded-2xl shadow-xl shadow-yellow-500/10"
                >
                  WITHDRAW NOW
                </button>
              </div>
            </div>
          )}

          {step === 'processing' && (
            <div className="py-12 flex flex-col items-center text-center space-y-6 animate-in fade-in zoom-in duration-500">
              <div className="relative">
                <div className="w-24 h-24 border-4 border-slate-800 rounded-full"></div>
                <Loader2 className="w-24 h-24 text-yellow-500 animate-spin absolute inset-0" />
              </div>
              <div>
                <h3 className="text-xl font-black text-white uppercase tracking-tight">Verifying Transaction</h3>
                <p className="text-xs text-slate-500 mt-2 font-bold uppercase tracking-widest">Encrypting through secure gateway...</p>
              </div>
            </div>
          )}

          {step === 'success' && (
            <div className="py-8 flex flex-col items-center text-center space-y-6 animate-in slide-in-from-bottom-8 duration-500">
              <div className="w-24 h-24 bg-green-500 rounded-full flex items-center justify-center shadow-[0_0_30px_rgba(34,197,94,0.4)]">
                <CheckCircle2 className="w-12 h-12 text-white" />
              </div>
              <div>
                <h3 className="text-2xl font-black text-white uppercase tracking-tight">Success!</h3>
                <p className="text-xs text-slate-400 mt-2 font-bold uppercase tracking-widest">
                  Withdrawal of <span className="text-green-500">${parseFloat(amount).toLocaleString()}</span> has been initiated.
                </p>
                <div className="mt-6 p-4 bg-slate-900/80 rounded-2xl border border-white/5 inline-block">
                  <p className="text-[9px] text-slate-500 font-black uppercase tracking-widest">Reference No.</p>
                  <p className="text-sm font-mono text-slate-300">STL-WD-{Math.random().toString(36).substr(2, 8).toUpperCase()}</p>
                </div>
              </div>
              <button 
                onClick={resetAndClose}
                className="w-full py-5 bg-slate-800 hover:bg-slate-700 text-white font-black rounded-3xl"
              >
                BACK TO LOBBY
              </button>
            </div>
          )}
        </div>

        <div className="p-4 bg-slate-950 border-t border-white/5 flex items-center justify-center gap-2">
          <ShieldCheck className="w-3 h-3 text-green-500" />
          <p className="text-[9px] text-slate-600 uppercase font-black tracking-widest">256-bit Secure SSL Channel</p>
        </div>
      </div>
    </div>
  );
};
