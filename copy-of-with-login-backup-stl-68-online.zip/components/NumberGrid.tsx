
import React from 'react';
import { MAX_NUMBER } from '../constants';

interface NumberGridProps {
  selectedNumbers: number[];
  onToggleNumber: (num: number) => void;
  disabled?: boolean;
}

export const NumberGrid: React.FC<NumberGridProps> = ({ selectedNumbers, onToggleNumber, disabled }) => {
  return (
    <div className="grid grid-cols-7 sm:grid-cols-10 gap-2 max-h-[400px] overflow-y-auto p-4 glass-morphism rounded-xl scrollbar-hide">
      {Array.from({ length: MAX_NUMBER }, (_, i) => i + 1).map((num) => {
        const isSelected = selectedNumbers.includes(num);
        return (
          <button
            key={num}
            onClick={() => onToggleNumber(num)}
            disabled={disabled && !isSelected}
            className={`
              w-full aspect-square flex items-center justify-center rounded-lg font-bold text-sm transition-all duration-200
              ${isSelected 
                ? 'bg-yellow-500 text-black shadow-lg shadow-yellow-500/50 scale-105' 
                : 'bg-slate-800 text-slate-400 hover:bg-slate-700 hover:text-white'}
              ${disabled && !isSelected ? 'opacity-50 cursor-not-allowed' : ''}
            `}
          >
            {num}
          </button>
        );
      })}
    </div>
  );
};
